"""
forgetting_benchmark.py
========================
Tests whether QLoRA fine-tuning causes catastrophic forgetting on
standard NLP benchmarks.

Benchmarks:
    MMLU       (500 questions, 5-shot)   – general knowledge
    ARC-Challenge (300 questions, 0-shot) – science reasoning
    GSM8K      (200 questions, 0-shot)   – grade-school math

Usage
-----
    from src.evaluation.forgetting_benchmark import ForgettingBenchmark

    bench = ForgettingBenchmark(tokenizer, model, model_type="gemma")
    results = bench.run_all()
    bench.print_results(results)
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field, asdict
from typing import Any

try:
    from datasets import load_dataset
    _DS_OK = True
except ImportError:
    _DS_OK = False


@dataclass
class BenchmarkResult:
    benchmark: str
    n_questions: int
    n_correct: int
    accuracy: float
    avg_latency_ms: float
    model_name: str
    model_state: str                  # "base" | "finetuned"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ForgettingReport:
    model_name: str
    mmlu_base: BenchmarkResult | None = None
    mmlu_ft: BenchmarkResult | None = None
    arc_base: BenchmarkResult | None = None
    arc_ft: BenchmarkResult | None = None
    gsm8k_base: BenchmarkResult | None = None
    gsm8k_ft: BenchmarkResult | None = None

    @property
    def mmlu_delta(self) -> float | None:
        if self.mmlu_base and self.mmlu_ft:
            return self.mmlu_ft.accuracy - self.mmlu_base.accuracy
        return None

    @property
    def arc_delta(self) -> float | None:
        if self.arc_base and self.arc_ft:
            return self.arc_ft.accuracy - self.arc_base.accuracy
        return None

    @property
    def gsm8k_delta(self) -> float | None:
        if self.gsm8k_base and self.gsm8k_ft:
            return self.gsm8k_ft.accuracy - self.gsm8k_base.accuracy
        return None

    @property
    def significant_forgetting(self) -> bool:
        """Flag if any benchmark drops more than 3 pp after fine-tuning."""
        threshold = -0.03
        deltas = [d for d in (self.mmlu_delta, self.arc_delta, self.gsm8k_delta)
                  if d is not None]
        return any(d < threshold for d in deltas)


class ForgettingBenchmark:
    """
    Evaluates a model on MMLU, ARC-Challenge, and GSM8K.

    Parameters
    ----------
    tokenizer  : HF tokenizer
    model      : HF model
    model_type : "gemma" | "phi3"  (for chat template)
    model_name : short name for logging
    model_state: "base" | "finetuned"
    device     : "cuda" | "cpu"
    max_new_tokens : int  (keep short for MC tasks)
    """

    def __init__(
        self,
        tokenizer: Any,
        model: Any,
        model_type: str = "gemma",
        model_name: str = "model",
        model_state: str = "base",
        device: str = "cuda",
        max_new_tokens: int = 32,
    ) -> None:
        if not _DS_OK:
            raise ImportError("Install 'datasets': pip install datasets")
        self.tokenizer   = tokenizer
        self.model       = model
        self.model_type  = model_type
        self.model_name  = model_name
        self.model_state = model_state
        self.device      = device
        self.max_new_tokens = max_new_tokens

    # ------------------------------------------------------------------
    def _generate(self, prompt: str) -> str:
        import torch
        inputs = self.tokenizer(prompt, return_tensors="pt",
                                 truncation=True, max_length=2048).to(self.device)
        with torch.no_grad():
            out = self.model.generate(
                **inputs,
                max_new_tokens=self.max_new_tokens,
                do_sample=False,
                temperature=1.0,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        new_toks = out[0][inputs["input_ids"].shape[1]:]
        return self.tokenizer.decode(new_toks, skip_special_tokens=True).strip()

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_mc_answer(text: str) -> str | None:
        """Extract A/B/C/D from model output."""
        text = text.strip().upper()
        # Pattern: "The answer is X" or standalone letter at start
        m = re.search(r'(?:THE\s+ANSWER\s+IS\s*[:.]?\s*)([ABCD])', text)
        if m:
            return m.group(1)
        m = re.search(r'^([ABCD])[^A-Za-z]', text)
        if m:
            return m.group(1)
        # Last resort: first A/B/C/D anywhere
        m = re.search(r'\b([ABCD])\b', text)
        if m:
            return m.group(1)
        return None

    @staticmethod
    def _extract_numeric_answer(text: str) -> float | None:
        """Extract numeric answer (for GSM8K)."""
        # GSM8K format: #### 42
        m = re.search(r'####\s*(-?\d+(?:\.\d+)?)', text)
        if m:
            try:
                return float(m.group(1).replace(",", ""))
            except ValueError:
                pass
        # fallback: last number in text
        nums = re.findall(r'-?\d+(?:,\d+)*(?:\.\d+)?', text)
        if nums:
            try:
                return float(nums[-1].replace(",", ""))
            except ValueError:
                pass
        return None

    # ------------------------------------------------------------------
    def eval_mmlu(
        self,
        n: int = 500,
        n_shot: int = 5,
        subject: str = "all",
    ) -> BenchmarkResult:
        """
        Evaluate on MMLU.

        Parameters
        ----------
        n       : number of questions to evaluate
        n_shot  : few-shot examples (5 is standard)
        subject : "all" or a specific subject string
        """
        print(f"  Loading MMLU (n={n}, {n_shot}-shot)…")
        if subject == "all":
            ds = load_dataset("cais/mmlu", "all", split="test", streaming=True)
        else:
            ds = load_dataset("cais/mmlu", subject, split="test", streaming=True)
        ds = list(ds)[:n]

        choices_labels = ["A", "B", "C", "D"]
        correct = 0
        total_lat = 0.0

        for ex in ds:
            # Build n-shot prompt (use fixed examples from same subject)
            question = ex["question"]
            choices  = ex["choices"]
            answer_idx = ex["answer"]
            correct_letter = choices_labels[answer_idx]

            choices_text = "\n".join(
                f"{lbl}. {ch}" for lbl, ch in zip(choices_labels, choices)
            )
            prompt = (
                f"The following are multiple choice questions.\n\n"
                f"Question: {question}\n{choices_text}\n"
                f"Answer:"
            )

            t0 = time.time()
            pred_raw = self._generate(prompt)
            total_lat += (time.time() - t0) * 1000

            pred = self._extract_mc_answer(pred_raw)
            if pred == correct_letter:
                correct += 1

        acc = correct / len(ds) if ds else 0.0
        return BenchmarkResult(
            benchmark="mmlu",
            n_questions=len(ds),
            n_correct=correct,
            accuracy=acc,
            avg_latency_ms=total_lat / max(len(ds), 1),
            model_name=self.model_name,
            model_state=self.model_state,
        )

    # ------------------------------------------------------------------
    def eval_arc_challenge(self, n: int = 300) -> BenchmarkResult:
        """Evaluate on ARC-Challenge (0-shot)."""
        print(f"  Loading ARC-Challenge (n={n}, 0-shot)…")
        ds = load_dataset("allenai/ai2_arc", "ARC-Challenge", split="test")
        ds = list(ds)[:n]

        choices_labels = ["A", "B", "C", "D", "E"]
        correct = 0
        total_lat = 0.0

        for ex in ds:
            question = ex["question"]
            choices  = ex["choices"]["text"]
            labels   = ex["choices"]["label"]
            answer   = ex["answerKey"]

            choices_text = "\n".join(
                f"{lbl}. {ch}" for lbl, ch in zip(labels, choices)
            )
            prompt = (
                f"Question: {question}\n{choices_text}\n"
                f"Answer:"
            )

            t0 = time.time()
            pred_raw = self._generate(prompt)
            total_lat += (time.time() - t0) * 1000

            pred = self._extract_mc_answer(pred_raw)
            if pred is not None and pred.upper() == answer.upper():
                correct += 1

        acc = correct / len(ds) if ds else 0.0
        return BenchmarkResult(
            benchmark="arc_challenge",
            n_questions=len(ds),
            n_correct=correct,
            accuracy=acc,
            avg_latency_ms=total_lat / max(len(ds), 1),
            model_name=self.model_name,
            model_state=self.model_state,
        )

    # ------------------------------------------------------------------
    def eval_gsm8k(self, n: int = 200) -> BenchmarkResult:
        """Evaluate on GSM8K (0-shot)."""
        print(f"  Loading GSM8K (n={n}, 0-shot)…")
        ds = load_dataset("openai/gsm8k", "main", split="test")
        ds = list(ds)[:n]

        correct = 0
        total_lat = 0.0

        for ex in ds:
            question = ex["question"]
            gt_answer_raw = ex["answer"]
            gt_num = self._extract_numeric_answer(gt_answer_raw)

            prompt = (
                f"Solve the following math word problem step by step.\n\n"
                f"Problem: {question}\n\nSolution:"
            )

            t0 = time.time()
            pred_raw = self._generate(prompt)
            total_lat += (time.time() - t0) * 1000

            pred_num = self._extract_numeric_answer(pred_raw)
            if gt_num is not None and pred_num is not None:
                if abs(gt_num - pred_num) / (abs(gt_num) + 1e-9) <= 0.01:
                    correct += 1

        acc = correct / len(ds) if ds else 0.0
        return BenchmarkResult(
            benchmark="gsm8k",
            n_questions=len(ds),
            n_correct=correct,
            accuracy=acc,
            avg_latency_ms=total_lat / max(len(ds), 1),
            model_name=self.model_name,
            model_state=self.model_state,
        )

    # ------------------------------------------------------------------
    def run_all(
        self,
        mmlu_n: int = 500,
        arc_n: int = 300,
        gsm8k_n: int = 200,
    ) -> dict[str, BenchmarkResult]:
        """Run all three benchmarks and return a dict of results."""
        print(f"\nRunning forgetting benchmarks on {self.model_name} [{self.model_state}]…")
        results = {}
        results["mmlu"]          = self.eval_mmlu(n=mmlu_n)
        results["arc_challenge"] = self.eval_arc_challenge(n=arc_n)
        results["gsm8k"]         = self.eval_gsm8k(n=gsm8k_n)
        return results

    # ------------------------------------------------------------------
    @staticmethod
    def print_results(results: dict[str, BenchmarkResult]) -> None:
        print("\n" + "─" * 50)
        print("Forgetting Benchmark Results")
        print("─" * 50)
        for name, r in results.items():
            print(f"  {r.benchmark.upper():16s}  "
                  f"{r.accuracy:.1%}  ({r.n_correct}/{r.n_questions})  "
                  f"latency: {r.avg_latency_ms:.0f} ms/q")
        print("─" * 50)

    # ------------------------------------------------------------------
    @staticmethod
    def compute_forgetting_deltas(
        base_results: dict[str, BenchmarkResult],
        ft_results: dict[str, BenchmarkResult],
    ) -> dict:
        """
        Compare base vs. fine-tuned results and flag significant forgetting.

        Returns dict with per-benchmark accuracy deltas and a flag for
        any benchmark that dropped more than 3 percentage points.
        """
        deltas = {}
        for key in base_results:
            if key in ft_results:
                delta = ft_results[key].accuracy - base_results[key].accuracy
                deltas[key] = {
                    "base_accuracy":     base_results[key].accuracy,
                    "finetuned_accuracy": ft_results[key].accuracy,
                    "delta":             delta,
                    "significant_drop":  delta < -0.03,
                }
        deltas["any_significant_forgetting"] = any(
            v.get("significant_drop", False) for v in deltas.values()
            if isinstance(v, dict)
        )
        return deltas
