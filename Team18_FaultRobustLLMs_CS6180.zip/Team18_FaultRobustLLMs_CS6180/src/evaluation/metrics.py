"""
metrics.py  (v2 – research grade)
====================================
Per-query and aggregate metrics including:
  – answer accuracy
  – tool selection accuracy
  – recovery rate
  – fault detection rate  (model correctly flagged a faulty result)
  – false alarm rate      (model flagged a clean result as faulty)
  – failure mode distribution  (4 categories)
  – avg retries / latency
  – statistical significance tests  (Mann-Whitney U, Kruskal-Wallis)
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, asdict, field
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats


# ---------------------------------------------------------------------------
# Failure mode taxonomy
# ---------------------------------------------------------------------------

class FailureMode:
    SILENT_WRONG      = "silent_wrong"      # wrong answer, model never flagged it
    EXPLICIT_ERROR    = "explicit_error"    # tool returned error, propagated unchanged
    HALLUCINATED_FIX  = "hallucinated_fix"  # model flagged → claimed fix → still wrong
    CORRECT_REFUSAL   = "correct_refusal"   # model correctly declined / flagged, no answer
    SUCCESS           = "success"           # correct answer produced


def classify_failure(
    answer_correct: bool,
    fault_injected: bool,
    fault_detected: bool,
    final_answer: str,
) -> str:
    """
    Assign one of 5 failure mode labels to a query result.
    Called after the full pipeline completes.
    """
    if answer_correct:
        return FailureMode.SUCCESS

    ans_lower = final_answer.lower()
    refused = any(kw in ans_lower for kw in [
        "i cannot", "i can't", "unable to", "could not", "failed",
        "no answer", "insufficient", "error", "not available",
    ])

    if fault_injected:
        if fault_detected and refused:
            return FailureMode.CORRECT_REFUSAL
        if fault_detected and not refused:
            return FailureMode.HALLUCINATED_FIX
        if not fault_detected:
            return FailureMode.SILENT_WRONG
    else:
        if refused:
            return FailureMode.EXPLICIT_ERROR
        return FailureMode.SILENT_WRONG

    return FailureMode.SILENT_WRONG


# ---------------------------------------------------------------------------
# Per-query result
# ---------------------------------------------------------------------------

@dataclass
class QueryResult:
    query_id: int
    user_query: str
    category: str                     # weather / math / database / search
    difficulty: str                   # easy / medium / hard

    # Tool call
    expected_tool: str
    predicted_tool: str | None
    tool_selection_correct: bool

    # Answer
    final_answer: str
    answer_correct: bool

    # Fault / recovery
    fault_injected: bool              # was a fault actually injected this call?
    fault_type: str
    injection_rate: float
    recovered: bool
    retries_used: int

    # Self-correction specific
    fault_detected: bool              # model said "retry" during SC verification
    false_alarm: bool                 # model said "retry" on a clean result

    # Failure mode
    failure_mode: str

    # Experiment metadata
    recovery_strategy: str
    model_name: str
    model_state: str                  # "base" | "finetuned"

    # Latency
    latency_ms: float
    node_trace: list[str] = field(default_factory=list)
    raw_tool_result: Any = None

    def to_dict(self) -> dict:
        d = asdict(self)
        try:
            d["raw_tool_result"] = json.dumps(self.raw_tool_result, default=str)
        except Exception:
            d["raw_tool_result"] = str(self.raw_tool_result)
        return d


# ---------------------------------------------------------------------------
# Aggregate metrics
# ---------------------------------------------------------------------------

@dataclass
class ExperimentMetrics:
    model_name: str
    model_state: str
    fault_type: str
    injection_rate: float
    recovery_strategy: str

    n_queries: int = 0
    n_correct: int = 0
    n_correct_tool: int = 0
    n_faulted: int = 0
    n_recovered: int = 0
    n_detected: int = 0
    n_false_alarms: int = 0
    total_retries: int = 0
    total_latency_ms: float = 0.0

    # Rates
    accuracy: float = 0.0
    tool_selection_accuracy: float = 0.0
    recovery_rate: float = 0.0
    fault_detection_rate: float = 0.0
    false_alarm_rate: float = 0.0
    avg_retries: float = 0.0
    avg_latency_ms: float = 0.0
    latency_std_ms: float = 0.0
    latency_p95_ms: float = 0.0

    # Failure mode distribution (sum = 1.0)
    pct_success: float = 0.0
    pct_silent_wrong: float = 0.0
    pct_explicit_error: float = 0.0
    pct_hallucinated_fix: float = 0.0
    pct_correct_refusal: float = 0.0

    def compute(self, results: list[QueryResult]) -> "ExperimentMetrics":
        self.n_queries = len(results)
        if not results:
            return self

        self.n_correct         = sum(r.answer_correct for r in results)
        self.n_correct_tool    = sum(r.tool_selection_correct for r in results)
        self.n_faulted         = sum(r.fault_injected for r in results)
        self.n_recovered       = sum(r.recovered for r in results if r.fault_injected)
        self.n_detected        = sum(r.fault_detected for r in results if r.fault_injected)
        self.n_false_alarms    = sum(r.false_alarm for r in results)
        self.total_retries     = sum(r.retries_used for r in results)
        self.total_latency_ms  = sum(r.latency_ms for r in results)

        n = self.n_queries
        self.accuracy                = self.n_correct / n
        self.tool_selection_accuracy = self.n_correct_tool / n
        self.recovery_rate           = (self.n_recovered / self.n_faulted
                                        if self.n_faulted > 0 else float("nan"))
        self.fault_detection_rate    = (self.n_detected / self.n_faulted
                                        if self.n_faulted > 0 else float("nan"))
        clean_results              = [r for r in results if not r.fault_injected]
        self.false_alarm_rate        = (self.n_false_alarms / len(clean_results)
                                        if clean_results else float("nan"))

        faulted = [r for r in results if r.fault_injected]
        self.avg_retries = (sum(r.retries_used for r in faulted) / len(faulted)
                            if faulted else 0.0)

        lats = [r.latency_ms for r in results]
        self.avg_latency_ms = float(np.mean(lats))
        self.latency_std_ms = float(np.std(lats))
        self.latency_p95_ms = float(np.percentile(lats, 95))

        # Failure mode distribution
        modes = [r.failure_mode for r in results]
        for mode_attr, mode_key in [
            ("pct_success",           FailureMode.SUCCESS),
            ("pct_silent_wrong",      FailureMode.SILENT_WRONG),
            ("pct_explicit_error",    FailureMode.EXPLICIT_ERROR),
            ("pct_hallucinated_fix",  FailureMode.HALLUCINATED_FIX),
            ("pct_correct_refusal",   FailureMode.CORRECT_REFUSAL),
        ]:
            setattr(self, mode_attr, modes.count(mode_key) / n)

        return self

    def to_dict(self) -> dict:
        return asdict(self)

    def summary_str(self) -> str:
        rr  = f"{self.recovery_rate:.1%}" if not math.isnan(self.recovery_rate) else "N/A"
        fdr = f"{self.fault_detection_rate:.1%}" if not math.isnan(self.fault_detection_rate) else "N/A"
        far = f"{self.false_alarm_rate:.1%}" if not math.isnan(self.false_alarm_rate) else "N/A"
        return "\n".join([
            f"Model: {self.model_name} [{self.model_state}]  "
            f"fault={self.fault_type}@{self.injection_rate:.0%}  strategy={self.recovery_strategy}",
            f"  Accuracy:          {self.accuracy:.1%}  ({self.n_correct}/{self.n_queries})",
            f"  Tool Selection:    {self.tool_selection_accuracy:.1%}",
            f"  Recovery Rate:     {rr}",
            f"  Fault Detection:   {fdr}  |  False Alarm: {far}",
            f"  Avg Retries:       {self.avg_retries:.2f}",
            f"  Avg Latency:       {self.avg_latency_ms:.0f} ms  (p95: {self.latency_p95_ms:.0f} ms)",
        ])


# ---------------------------------------------------------------------------
# Statistical tests
# ---------------------------------------------------------------------------

def mann_whitney_u(
    group_a: list[float],
    group_b: list[float],
    label_a: str = "A",
    label_b: str = "B",
) -> dict:
    """Two-sided Mann-Whitney U test between two accuracy distributions."""
    if len(group_a) < 2 or len(group_b) < 2:
        return {"statistic": None, "p_value": None,
                "significant": False, "label_a": label_a, "label_b": label_b}
    stat, p = stats.mannwhitneyu(group_a, group_b, alternative="two-sided")
    return {
        "test": "mann_whitney_u",
        "statistic": float(stat),
        "p_value": float(p),
        "significant": p < 0.05,
        "label_a": label_a, "mean_a": float(np.mean(group_a)),
        "label_b": label_b, "mean_b": float(np.mean(group_b)),
    }


def kruskal_wallis(groups: dict[str, list[float]]) -> dict:
    """Kruskal-Wallis H-test across multiple strategy groups."""
    arrays = list(groups.values())
    if any(len(a) < 2 for a in arrays):
        return {"statistic": None, "p_value": None, "significant": False}
    stat, p = stats.kruskal(*arrays)
    return {
        "test": "kruskal_wallis",
        "statistic": float(stat),
        "p_value": float(p),
        "significant": p < 0.05,
        "groups": {k: float(np.mean(v)) for k, v in groups.items()},
    }


def run_statistical_tests(df: pd.DataFrame) -> dict:
    """
    Run all pairwise Mann-Whitney U and Kruskal-Wallis tests on the raw
    results DataFrame.  Compares:
      1. base vs. finetuned (per model, per fault)
      2. self_correction vs. majority_voting (per model, per fault)
      3. Gemma vs. Phi-3 (per state, per fault)
    Returns a dict of test results.
    """
    results = {}

    # 1. Base vs. finetuned per model per fault
    for model in df["model_name"].unique():
        for fault in df["fault_type"].unique():
            subset = df[(df["model_name"] == model) & (df["fault_type"] == fault)]
            a = subset[subset["model_state"] == "base"]["answer_correct"].astype(int).tolist()
            b = subset[subset["model_state"] == "finetuned"]["answer_correct"].astype(int).tolist()
            key = f"base_vs_ft__{model}__{fault}"
            results[key] = mann_whitney_u(a, b,
                                          label_a=f"{model}/base",
                                          label_b=f"{model}/finetuned")

    # 2. SC vs. MV per model per fault
    for model in df["model_name"].unique():
        for fault in df[df["fault_type"] != "none"]["fault_type"].unique():
            subset = df[(df["model_name"] == model) & (df["fault_type"] == fault)]
            a = subset[subset["recovery_strategy"] == "self_correction"]["answer_correct"].astype(int).tolist()
            b = subset[subset["recovery_strategy"] == "majority_voting"]["answer_correct"].astype(int).tolist()
            key = f"sc_vs_mv__{model}__{fault}"
            results[key] = mann_whitney_u(a, b,
                                          label_a="self_correction",
                                          label_b="majority_voting")

    # 3. Kruskal-Wallis across all 4 strategies per fault
    for fault in df[df["fault_type"] != "none"]["fault_type"].unique():
        groups = {}
        for (model, state), g in df[df["fault_type"] == fault].groupby(["model_name", "model_state"]):
            k = f"{model}/{state}"
            groups[k] = g["answer_correct"].astype(int).tolist()
        key = f"kruskal__{fault}"
        results[key] = kruskal_wallis(groups)

    return results


# ---------------------------------------------------------------------------
# MetricsTracker
# ---------------------------------------------------------------------------

class MetricsTracker:
    def __init__(self) -> None:
        self._results: list[QueryResult] = []

    def add(self, r: QueryResult) -> None:
        self._results.append(r)

    def add_batch(self, rs: list[QueryResult]) -> None:
        self._results.extend(rs)

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame([r.to_dict() for r in self._results])

    def aggregate(self) -> pd.DataFrame:
        df = self.to_dataframe()
        if df.empty:
            return df
        rows = []
        keys = ["model_name", "model_state", "fault_type", "injection_rate", "recovery_strategy"]
        for key_vals, _ in df.groupby(keys):
            subset = [
                r for r in self._results
                if (r.model_name == key_vals[0]
                    and r.model_state == key_vals[1]
                    and r.fault_type == key_vals[2]
                    and r.injection_rate == key_vals[3]
                    and r.recovery_strategy == key_vals[4])
            ]
            em = ExperimentMetrics(
                model_name=key_vals[0], model_state=key_vals[1],
                fault_type=key_vals[2], injection_rate=key_vals[3],
                recovery_strategy=key_vals[4],
            ).compute(subset)
            rows.append(em.to_dict())
        return pd.DataFrame(rows)

    def statistical_tests(self) -> dict:
        return run_statistical_tests(self.to_dataframe())

    def save(self, results_dir: str = "./results") -> tuple[str, str, str]:
        os.makedirs(results_dir, exist_ok=True)
        raw_path  = os.path.join(results_dir, "raw_results.csv")
        agg_path  = os.path.join(results_dir, "aggregate_metrics.csv")
        stat_path = os.path.join(results_dir, "statistical_tests.json")

        self.to_dataframe().to_csv(raw_path,  index=False)
        self.aggregate().to_csv(agg_path, index=False)
        with open(stat_path, "w") as f:
            json.dump(self.statistical_tests(), f, indent=2, default=str)

        print(f"Saved: {raw_path}")
        print(f"Saved: {agg_path}")
        print(f"Saved: {stat_path}")
        return raw_path, agg_path, stat_path

    def print_summary(self) -> None:
        agg = self.aggregate()
        if agg.empty:
            print("No results yet.")
            return
        print("\n" + "=" * 72)
        print("EXPERIMENT SUMMARY")
        print("=" * 72)
        for _, row in agg.iterrows():
            em = ExperimentMetrics(**{k: row[k] for k in row.index})
            print(em.summary_str())
            print("-" * 40)
