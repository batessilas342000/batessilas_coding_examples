"""
test_suite.py  (v2 – 200 generated tasks)
==========================================
200 evaluation tasks generated programmatically with template variation
and random value substitution.  50 tasks per tool category.

Each Task has:
    task_id          : int
    prompt           : str  (natural-language user query)
    expected_tool    : str
    expected_args    : dict (canonical args the model should produce)
    ground_truth     : dict (what the tool returns for expected_args)
    answer_check_fn  : callable(final_answer: str) -> bool
    difficulty       : "easy" | "medium" | "hard"
    category         : "weather" | "math" | "database" | "search"
    tags             : list[str]
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable

from ..tools.simulated_tools import (
    weather_lookup, calculator, database_query, web_search
)

_RNG_SEED = 42
import random as _random
_rng = _random.Random(_RNG_SEED)


@dataclass
class Task:
    task_id: int
    prompt: str
    expected_tool: str
    expected_args: dict
    ground_truth: Any
    answer_check_fn: Callable[[str], bool]
    difficulty: str = "easy"
    category: str = "general"
    tags: list[str] = field(default_factory=list)

    def check_answer(self, answer: str) -> bool:
        try:
            return self.answer_check_fn(answer)
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _contains_number(text: str, value: float, tol: float = 0.03) -> bool:
    nums = re.findall(r'-?\d+(?:[.,]\d+)?', text.replace(',', ''))
    for n in nums:
        try:
            if abs(float(n) - value) / (abs(value) + 1e-9) <= tol:
                return True
        except ValueError:
            pass
    return False


def _contains_any(text: str, keywords: list[str]) -> bool:
    t = text.lower()
    return any(k.lower() in t for k in keywords)


# ============================================================================
# WEATHER  (50 tasks)
# ============================================================================

_WEATHER_CITIES = [
    "New York", "Boston", "London", "Chicago", "Los Angeles",
    "Seattle", "Miami", "Austin", "Denver", "Toronto",
]
_DATE_LABELS = ["today", "tomorrow", "2024-12-01", "2024-12-02",
                "2025-01-15", "2025-06-01"]
_WEATHER_TEMPLATES = [
    "What is the weather in {city} {date_phrase}?",
    "What's the temperature in {city} {date_phrase}?",
    "Can you check the weather forecast for {city} {date_phrase}?",
    "How hot or cold is it going to be in {city} {date_phrase}?",
    "Tell me the current weather conditions in {city} {date_phrase}.",
    "What should I wear in {city} {date_phrase}?",
    "Is it raining in {city} {date_phrase}?",
]
_DATE_PHRASES = {
    "today": ["today", "right now", "currently", "at the moment"],
    "tomorrow": ["tomorrow", "the next day", "tomorrow's forecast"],
    "2024-12-01": ["on December 1st 2024", "on 2024-12-01", "December 1 2024"],
    "2024-12-02": ["on December 2nd 2024", "on 2024-12-02"],
    "2025-01-15": ["on January 15th 2025", "on 2025-01-15"],
    "2025-06-01": ["on June 1st 2025", "on 2025-06-01"],
}


def _make_weather_tasks(start_id: int, n: int = 50) -> list[Task]:
    tasks = []
    combos = [
        (city, date)
        for city in _WEATHER_CITIES
        for date in _DATE_LABELS
    ]
    _rng.shuffle(combos)
    for i, (city, date) in enumerate(combos[:n]):
        gt = weather_lookup(city=city, date=date)
        temp_f    = gt["data"]["temperature_f"]
        condition = gt["data"]["condition"]
        template  = _rng.choice(_WEATHER_TEMPLATES)
        date_phrase = _rng.choice(_DATE_PHRASES.get(date, [date]))
        prompt = template.format(city=city, date_phrase=date_phrase)
        difficulty = "easy" if date in ("today", "tomorrow") else "medium"

        def _mk_check(t: float, c: str):
            def _chk(ans: str) -> bool:
                return _contains_number(ans, t, tol=0.12) or c.lower() in ans.lower()
            return _chk

        tasks.append(Task(
            task_id=start_id + i,
            prompt=prompt,
            expected_tool="weather_lookup",
            expected_args={"city": city, "date": date},
            ground_truth=gt,
            answer_check_fn=_mk_check(temp_f, condition),
            difficulty=difficulty,
            category="weather",
            tags=["weather", city.lower().replace(" ", "_"), date],
        ))
    return tasks


# ============================================================================
# MATH / CALCULATOR  (50 tasks)
# ============================================================================

_MATH_TEMPLATES: list[tuple[str, str, Callable]] = [
    # (prompt_template, expr_template, gt_fn)
    ("What is {a}% of {b}?",             "{b}*{a}/100",            lambda a, b: b * a / 100),
    ("Calculate {a} times {b}.",          "{a}*{b}",                lambda a, b: a * b),
    ("What is {a} divided by {b}?",       "{a}/{b}",                lambda a, b: a / b),
    ("Add {a} and {b}.",                  "{a}+{b}",                lambda a, b: a + b),
    ("Subtract {b} from {a}.",            "{a}-{b}",                lambda a, b: a - b),
    ("What is {a} to the power of {b}?",  "{a}**{b}",               lambda a, b: a ** b),
    ("What is the square root of {a}?",   "sqrt({a})",              lambda a, b: math.sqrt(a)),
    ("Calculate {a}% tip on ${b}.",       "{b}*{a}/100",            lambda a, b: b * a / 100),
    ("What is {a} squared?",              "{a}**2",                 lambda a, b: a ** 2),
    ("Divide {a} by {b} and round to 2 decimal places.", "round({a}/{b},2)", lambda a, b: round(a / b, 2)),
    ("If I save ${a} per month for {b} months, total?", "{a}*{b}",  lambda a, b: a * b),
    ("Area of a rectangle {a} by {b}.",   "{a}*{b}",                lambda a, b: a * b),
    ("What is log base 10 of {a}?",       "log10({a})",             lambda a, b: math.log10(a)),
    ("Convert {a} Celsius to Fahrenheit.", "{a}*9/5+32",            lambda a, b: a * 9 / 5 + 32),
    ("How many seconds in {a} hours?",    "{a}*3600",               lambda a, b: a * 3600),
    ("Hypotenuse of right triangle legs {a} and {b}.", "sqrt({a}**2+{b}**2)", lambda a, b: math.sqrt(a**2 + b**2)),
    ("What is {a} modulo {b}?",           "{a}%{b}",                lambda a, b: a % b),
    ("Area of a circle with radius {a}.", "pi*{a}**2",              lambda a, b: math.pi * a ** 2),
    ("What is {a} factorial?",            "factorial({a})",         lambda a, b: math.factorial(a)),
    ("What is floor of {a} divided by {b}?", "floor({a}/{b})",      lambda a, b: math.floor(a / b)),
]

_A_VALS = [2, 3, 5, 7, 8, 9, 10, 12, 15, 16, 18, 20, 25, 50, 100, 144, 200, 365]
_B_VALS = [2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 18, 20, 24, 25, 30, 50, 100]


def _make_math_tasks(start_id: int, n: int = 50) -> list[Task]:
    tasks = []
    seen_prompts: set[str] = set()
    attempts = 0
    while len(tasks) < n and attempts < 5000:
        attempts += 1
        tmpl_idx = _rng.randrange(len(_MATH_TEMPLATES))
        prompt_tmpl, expr_tmpl, gt_fn = _MATH_TEMPLATES[tmpl_idx]
        a = _rng.choice(_A_VALS)
        b = _rng.choice(_B_VALS)

        # Guard against invalid operations
        if "{b}" in expr_tmpl and b == 0:
            continue
        if "log10" in expr_tmpl and a <= 0:
            continue
        if "sqrt" in expr_tmpl and a < 0:
            continue
        if "factorial" in expr_tmpl and a > 12:
            a = _rng.choice([3, 4, 5, 6, 7, 8, 9, 10])
        if "**" in expr_tmpl and prompt_tmpl.count("{b}") > 0 and b > 10:
            b = _rng.choice([2, 3, 4])
        if "{a}%{b}" in expr_tmpl and b == 0:
            continue

        prompt = prompt_tmpl.format(a=a, b=b)
        if prompt in seen_prompts:
            continue
        seen_prompts.add(prompt)

        try:
            expected_val = gt_fn(a, b)
        except Exception:
            continue

        expr = expr_tmpl.format(a=a, b=b)
        gt = calculator(expression=expr)
        if gt["status"] == "error":
            gt = {"status": "ok", "data": {"expression": expr, "result": float(expected_val)},
                  "tool": "calculator"}

        difficulty = (
            "easy" if tmpl_idx < 5
            else "medium" if tmpl_idx < 12
            else "hard"
        )

        def _mk_check(v: float):
            def _chk(ans: str) -> bool:
                return _contains_number(ans, v, tol=0.03)
            return _chk

        tasks.append(Task(
            task_id=start_id + len(tasks),
            prompt=prompt,
            expected_tool="calculator",
            expected_args={"expression": expr},
            ground_truth=gt,
            answer_check_fn=_mk_check(float(expected_val)),
            difficulty=difficulty,
            category="math",
            tags=["math", "calculator"],
        ))
    return tasks


# ============================================================================
# DATABASE  (50 tasks)
# ============================================================================

_DB_TEMPLATES: list[tuple[str, str, dict, list[str]]] = [
    # (prompt, table, filters, answer_keywords)
    ("Show me the first 5 customers.",                    "customers", {},                ["Customer_",   "email"]),
    ("List all gold tier customers.",                     "customers", {"tier": "gold"},   ["gold"]),
    ("List all platinum tier customers.",                 "customers", {"tier": "platinum"}, ["platinum"]),
    ("List all silver tier customers.",                   "customers", {"tier": "silver"}, ["silver"]),
    ("List all bronze tier customers.",                   "customers", {"tier": "bronze"}, ["bronze"]),
    ("Get details for customer with id {cid}.",           "customers", {},                ["Customer_"]),
    ("Show products in the electronics category.",        "products",  {"category": "electronics"}, ["electronics"]),
    ("List books in our inventory.",                      "products",  {"category": "books"},        ["books"]),
    ("Show clothing products.",                           "products",  {"category": "clothing"},     ["clothing"]),
    ("What home products do we have?",                    "products",  {"category": "home"},         ["home"]),
    ("Show delivered orders.",                            "orders",    {"status": "delivered"},      ["delivered"]),
    ("List all pending orders.",                          "orders",    {"status": "pending"},        ["pending"]),
    ("What orders have been shipped?",                    "orders",    {"status": "shipped"},        ["shipped"]),
    ("How many cancelled orders are there?",              "orders",    {"status": "cancelled"},      ["cancelled"]),
    ("Show me the first 5 products.",                     "products",  {},                           ["Product_"]),
    ("Show me the first 5 orders.",                       "orders",    {},                           ["order"]),
    ("Get customer {cid} information.",                   "customers", {},                           ["Customer_"]),
    ("Look up product id {pid} details.",                 "products",  {},                           ["Product_"]),
    ("Show order {oid} details.",                         "orders",    {},                           ["status"]),
    ("List customers who have spent more than $100.",     "customers", {},                           ["Customer_", "email"]),
]

_CID_POOL = list(range(1, 21))
_PID_POOL = list(range(1, 21))
_OID_POOL = list(range(1, 21))


def _make_db_tasks(start_id: int, n: int = 50) -> list[Task]:
    tasks = []
    seen: set[str] = set()
    attempts = 0
    while len(tasks) < n and attempts < 2000:
        attempts += 1
        row = _rng.choice(_DB_TEMPLATES)
        prompt_tmpl, table, base_filters, keywords = row
        cid = _rng.choice(_CID_POOL)
        pid = _rng.choice(_PID_POOL)
        oid = _rng.choice(_OID_POOL)
        prompt = prompt_tmpl.format(cid=cid, pid=pid, oid=oid)
        if prompt in seen:
            continue
        seen.add(prompt)

        # Build filters (add id filter where template uses {cid}/{pid}/{oid})
        filters = dict(base_filters)
        if "{cid}" in prompt_tmpl and table == "customers":
            filters = {"id": str(cid)}
        if "{pid}" in prompt_tmpl and table == "products":
            filters = {"id": str(pid)}
        if "{oid}" in prompt_tmpl and table == "orders":
            filters = {"id": str(oid)}

        gt = database_query(table=table, filters=filters if filters else None, limit=5)
        difficulty = "easy" if not filters else "medium"

        def _mk_check(kws: list[str]):
            def _chk(ans: str) -> bool:
                return _contains_any(ans, kws + ["found", "result", "record", "row"])
            return _chk

        tasks.append(Task(
            task_id=start_id + len(tasks),
            prompt=prompt,
            expected_tool="database_query",
            expected_args={"table": table, "filters": filters, "limit": 5},
            ground_truth=gt,
            answer_check_fn=_mk_check(keywords),
            difficulty=difficulty,
            category="database",
            tags=["database", table],
        ))
    return tasks


# ============================================================================
# WEB SEARCH  (50 tasks)
# ============================================================================

_SEARCH_TEMPLATES: list[tuple[str, list[str]]] = [
    ("Search for recent news about {topic}.",           ["{topic_kw}"]),
    ("Find articles about {topic}.",                    ["{topic_kw}", "result"]),
    ("Look up information on {topic}.",                 ["{topic_kw}", "found"]),
    ("What are the latest developments in {topic}?",    ["{topic_kw}"]),
    ("Give me web results for {topic}.",                ["result"]),
    ("Research {topic} and summarize what you find.",   ["{topic_kw}", "result"]),
    ("Find recent publications about {topic}.",         ["{topic_kw}", "found"]),
]
_SEARCH_TOPICS: list[tuple[str, str]] = [
    ("artificial intelligence", "ai"),
    ("machine learning", "ai"),
    ("large language models", "ai"),
    ("generative AI", "ai"),
    ("neural networks", "ai"),
    ("climate change", "climate"),
    ("global warming", "climate"),
    ("renewable energy", "climate"),
    ("carbon emissions", "climate"),
    ("Paris Agreement", "climate"),
    ("Python programming", "python"),
    ("Python data science", "python"),
    ("Python async IO", "python"),
    ("Python machine learning", "python"),
    ("Python web development", "python"),
    ("stock market", "stock"),
    ("S&P 500", "stock"),
    ("cryptocurrency", "stock"),
    ("investment strategies", "stock"),
    ("financial markets", "stock"),
    ("deep learning research", "ai"),
    ("transformer architecture", "ai"),
    ("electric vehicles", "climate"),
    ("solar energy", "climate"),
    ("Python best practices", "python"),
]


def _make_search_tasks(start_id: int, n: int = 50) -> list[Task]:
    tasks = []
    seen: set[str] = set()
    topic_list = _SEARCH_TOPICS * 3  # enough variety
    _rng.shuffle(topic_list)
    for i, (topic, kw) in enumerate(topic_list[:n]):
        template, raw_kws = _rng.choice(_SEARCH_TEMPLATES)
        prompt = template.format(topic=topic)
        if prompt in seen:
            # slight variation
            prompt = f"Please {prompt[0].lower() + prompt[1:]}"
        seen.add(prompt)
        gt = web_search(query=prompt, num_results=3)
        keywords = [kw_ .replace("{topic_kw}", kw) for kw_ in raw_kws]

        def _mk_check(kws: list[str]):
            def _chk(ans: str) -> bool:
                return _contains_any(ans, kws + ["result", "found", "search", "here"])
            return _chk

        tasks.append(Task(
            task_id=start_id + i,
            prompt=prompt,
            expected_tool="web_search",
            expected_args={"query": prompt, "num_results": 3},
            ground_truth=gt,
            answer_check_fn=_mk_check(keywords),
            difficulty="easy",
            category="search",
            tags=["search", kw],
        ))
    return tasks[:n]


# ============================================================================
# Build full 200-task suite
# ============================================================================

def build_task_suite(seed: int = 42) -> list[Task]:
    global _rng
    _rng = _random.Random(seed)
    weather_tasks  = _make_weather_tasks(start_id=1,   n=50)
    math_tasks     = _make_math_tasks(   start_id=51,  n=50)
    db_tasks       = _make_db_tasks(     start_id=101, n=50)
    search_tasks   = _make_search_tasks( start_id=151, n=50)
    all_tasks = weather_tasks + math_tasks + db_tasks + search_tasks
    assert len(all_tasks) == 200, f"Expected 200, got {len(all_tasks)}"
    return all_tasks


# Module-level default (seed=42)
TASKS: list[Task] = build_task_suite()

# Backward-compatible alias
TEST_CASES = TASKS
TestCase   = Task
