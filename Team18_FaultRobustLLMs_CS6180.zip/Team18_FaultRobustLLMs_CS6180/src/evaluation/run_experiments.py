"""
run_experiments.py  (v2 – research grade)
==========================================
Full experiment matrix:

    4 checkpoints (gemma_base, gemma_ft, phi3_base, phi3_ft)
  × 4 fault conditions (none + 3 fault types)
  × 3 injection rates  (0.0, 0.3, 0.7)  – skipped for fault_type=none
  × 3 recovery strategies (none, self_correction, majority_voting)
  × 200 queries
  = 7,200  evaluations  (+800 clean baseline)

Supports --skip_existing for resuming interrupted runs (results stream
to JSONL so partial progress is never lost).
"""

from __future__ import annotations

import gc
import json
import os
import time
import traceback
from typing import Any, Callable

from ..agent.pipeline import AgentPipeline, parse_tool_call
from ..agent.prompts import build_system_prompt
from ..tools.simulated_tools import TOOL_REGISTRY, TOOL_SCHEMAS
from ..tools.fault_injector import FaultInjector, FaultConfig, FaultType
from .test_suite import TASKS, Task
from .metrics import (
    MetricsTracker, QueryResult, ExperimentMetrics, classify_failure
)
from ..tools.fault_injector import is_faulty_output


# ---------------------------------------------------------------------------
# Experiment matrix constants
# ---------------------------------------------------------------------------

FAULT_TYPES = [FaultType.NULL_RETURN, FaultType.WRONG_OUTPUT, FaultType.BAD_FORMAT]
INJECTION_RATES = [0.3, 0.7]           # 0.0 handled via the "none" fault_type
RECOVERY_STRATEGIES = ["none", "self_correction", "majority_voting"]


def experiment_id(
    model_name: str,
    model_state: str,
    fault_type: str,
    injection_rate: float,
    strategy: str,
) -> str:
    return f"{model_name}__{model_state}__{fault_type}__{injection_rate:.2f}__{strategy}"


# ---------------------------------------------------------------------------
# ExperimentRunner
# ---------------------------------------------------------------------------

class ExperimentRunner:
    """
    Parameters
    ----------
    model_configs : dict
        {
          "gemma": {
              "base":      {"tokenizer": ..., "model": ...},
              "finetuned": {"tokenizer": ..., "model": ...},
          },
          "phi3": { ... }
        }
    results_dir  : str
    max_retries  : int  (self-correction)
    mv_k         : int  (majority voting samples)
    mv_temp      : float
    device       : str
    skip_existing: bool  – skip cells whose JSONL file already exists
    verbose      : bool
    """

    def __init__(
        self,
        model_configs: dict[str, dict[str, dict]],
        results_dir: str = "./results",
        max_retries: int = 3,
        mv_k: int = 3,
        mv_temp: float = 0.8,
        device: str = "cuda",
        skip_existing: bool = True,
        verbose: bool = True,
    ) -> None:
        self.model_configs  = model_configs
        self.results_dir    = results_dir
        self.max_retries    = max_retries
        self.mv_k           = mv_k
        self.mv_temp        = mv_temp
        self.device         = device
        self.skip_existing  = skip_existing
        self.verbose        = verbose
        self.tracker        = MetricsTracker()
        self._system_prompt = build_system_prompt(TOOL_SCHEMAS)
        os.makedirs(results_dir, exist_ok=True)
        os.makedirs(os.path.join(results_dir, "cells"), exist_ok=True)

    # ------------------------------------------------------------------
    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg)

    def _cell_path(self, exp_id: str) -> str:
        return os.path.join(self.results_dir, "cells", f"{exp_id}.jsonl")

    # ------------------------------------------------------------------
    def _run_single(
        self,
        task: Task,
        pipeline: AgentPipeline,
        fault_type_str: str,
        injection_rate: float,
        strategy: str,
        model_name: str,
        model_state: str,
    ) -> QueryResult:
        try:
            state = pipeline.run(
                user_query=task.prompt,
                fault_type=fault_type_str,
                model_state=model_state,
            )
            predicted_tool = state.tool_name
            tool_sel_ok    = (predicted_tool == task.expected_tool
                              if predicted_tool else False)
            answer_ok      = task.check_answer(state.final_answer)

            # Gather SC-specific fields from state if available
            fault_detected = getattr(state, "fault_detected", state.tool_result_is_faulty)
            false_alarm    = getattr(state, "false_alarm", False)

            # Did a fault actually get injected on this particular call?
            fault_injected = (
                fault_type_str != "none" and injection_rate > 0
                and state.tool_result_is_faulty
            )

            failure_mode = classify_failure(
                answer_correct=answer_ok,
                fault_injected=fault_injected,
                fault_detected=fault_detected,
                final_answer=state.final_answer,
            )

            return QueryResult(
                query_id=task.task_id,
                user_query=task.prompt,
                category=task.category,
                difficulty=task.difficulty,
                expected_tool=task.expected_tool,
                predicted_tool=predicted_tool,
                tool_selection_correct=tool_sel_ok,
                final_answer=state.final_answer,
                answer_correct=answer_ok,
                fault_injected=fault_injected,
                fault_type=fault_type_str,
                injection_rate=injection_rate,
                recovered=state.recovered,
                retries_used=state.retries_used,
                fault_detected=fault_detected,
                false_alarm=false_alarm,
                failure_mode=failure_mode,
                recovery_strategy=strategy,
                model_name=model_name,
                model_state=model_state,
                latency_ms=state.latency_ms,
                node_trace=state.node_trace,
                raw_tool_result=state.tool_result,
            )
        except Exception as e:
            self._log(f"  ⚠ Error task {task.task_id}: {e}")
            if self.verbose:
                traceback.print_exc()
            return QueryResult(
                query_id=task.task_id, user_query=task.prompt,
                category=task.category, difficulty=task.difficulty,
                expected_tool=task.expected_tool, predicted_tool=None,
                tool_selection_correct=False, final_answer="[ERROR]",
                answer_correct=False, fault_injected=False,
                fault_type=fault_type_str, injection_rate=injection_rate,
                recovered=False, retries_used=0,
                fault_detected=False, false_alarm=False,
                failure_mode="explicit_error",
                recovery_strategy=strategy, model_name=model_name,
                model_state=model_state, latency_ms=0.0,
            )

    # ------------------------------------------------------------------
    def run_condition(
        self,
        model_name: str,
        model_state: str,
        fault_type: FaultType | str,
        injection_rate: float,
        strategy: str,
        tasks: list[Task] | None = None,
    ) -> list[QueryResult]:
        """Run one cell of the experiment matrix."""
        fault_type_str = FaultType(fault_type).value if isinstance(fault_type, FaultType) else fault_type
        exp_id = experiment_id(model_name, model_state, fault_type_str, injection_rate, strategy)
        cell_path = self._cell_path(exp_id)

        if self.skip_existing and os.path.exists(cell_path):
            self._log(f"  ↩ Skipping existing cell: {exp_id}")
            return self._load_cell(cell_path)

        cfg = self.model_configs.get(model_name, {}).get(model_state, {})
        tokenizer = cfg.get("tokenizer")
        model     = cfg.get("model")
        mtype     = "gemma" if "gemma" in model_name.lower() else "phi3"

        # Wrap tools with fault injection
        if fault_type_str != "none" and injection_rate > 0:
            fault_cfg = FaultConfig(
                fault_type=FaultType(fault_type_str),
                injection_rate=injection_rate,
                seed=42,
            )
            tool_registry = FaultInjector(fault_cfg).wrap_registry(
                TOOL_REGISTRY, fault_type=fault_type_str,
                injection_rate=injection_rate, seed=42,
            )
        else:
            tool_registry = TOOL_REGISTRY.copy()

        pipeline = AgentPipeline(
            model_name=model_name, model_type=mtype,
            tokenizer=tokenizer, model=model,
            tool_registry=tool_registry,
            system_prompt=self._system_prompt,
            recovery_strategy=strategy if strategy != "none" else "self_correction",
            max_retries=self.max_retries if strategy != "none" else 0,
            n_mv_samples=self.mv_k,
            mv_temperature=self.mv_temp,
            device=self.device,
        )

        used_tasks = tasks or TASKS
        label = (f"{model_name}/{model_state} | {fault_type_str}@{injection_rate:.0%} "
                 f"| {strategy} | {len(used_tasks)} tasks")
        self._log(f"\n{'─' * 65}\n  {label}\n{'─' * 65}")

        results: list[QueryResult] = []
        with open(cell_path, "w") as f:
            for i, task in enumerate(used_tasks):
                if self.verbose and (i + 1) % 25 == 0:
                    self._log(f"  [{i+1}/{len(used_tasks)}]")
                qr = self._run_single(
                    task, pipeline, fault_type_str, injection_rate,
                    strategy, model_name, model_state,
                )
                results.append(qr)
                self.tracker.add(qr)
                f.write(json.dumps(qr.to_dict()) + "\n")
                f.flush()

        n_ok = sum(r.answer_correct for r in results)
        self._log(f"  Done. Accuracy = {n_ok}/{len(results)} = {n_ok/len(results):.1%}")

        # Free GPU memory between cells
        try:
            import torch, gc as _gc
            _gc.collect()
            torch.cuda.empty_cache()
        except Exception:
            pass

        return results

    # ------------------------------------------------------------------
    def _load_cell(self, path: str) -> list[QueryResult]:
        """Reload a previously saved JSONL cell."""
        results = []
        with open(path) as f:
            for line in f:
                d = json.loads(line)
                # reconstruct QueryResult (ignore extra fields gracefully)
                valid_keys = QueryResult.__dataclass_fields__.keys()
                filtered = {k: v for k, v in d.items() if k in valid_keys}
                results.append(QueryResult(**filtered))
        self.tracker.add_batch(results)
        return results

    # ------------------------------------------------------------------
    def run_all(
        self,
        tasks: list[Task] | None = None,
    ) -> MetricsTracker:
        """Run the full experiment matrix."""
        self._log("\n" + "=" * 72 + "\nSTARTING FULL EXPERIMENT RUN\n" + "=" * 72)
        t0 = time.time()

        for model_name in self.model_configs:
            for model_state in self.model_configs[model_name]:
                # Clean baseline
                self.run_condition(
                    model_name, model_state,
                    fault_type="none", injection_rate=0.0,
                    strategy="none", tasks=tasks,
                )
                # Fault × rate × strategy
                for ft in FAULT_TYPES:
                    for rate in INJECTION_RATES:
                        for strategy in RECOVERY_STRATEGIES:
                            if strategy == "none":
                                continue   # no-recovery with fault already done above
                            self.run_condition(
                                model_name, model_state,
                                fault_type=ft, injection_rate=rate,
                                strategy=strategy, tasks=tasks,
                            )

        elapsed = time.time() - t0
        self._log(f"\n{'=' * 72}\nALL EXPERIMENTS DONE  ({elapsed:.0f}s)\n{'=' * 72}\n")
        self.tracker.print_summary()
        return self.tracker

    # ------------------------------------------------------------------
    def run_mvp(
        self,
        tasks: list[Task] | None = None,
        n_tasks: int = 50,
    ) -> MetricsTracker:
        """
        MVP subset: 2 fault types × 1 rate (0.3) × 2 strategies × 4 checkpoints
        × n_tasks = 800 evaluations.  Fast sanity-check before full run.
        """
        self._log("\n" + "=" * 72 + "\nMVP EXPERIMENT RUN\n" + "=" * 72)
        mvp_tasks = (tasks or TASKS)[:n_tasks]

        for model_name in self.model_configs:
            for model_state in self.model_configs[model_name]:
                # Clean baseline (reduced)
                self.run_condition(
                    model_name, model_state,
                    fault_type="none", injection_rate=0.0,
                    strategy="none", tasks=mvp_tasks,
                )
                for ft in [FaultType.NULL_RETURN, FaultType.WRONG_OUTPUT]:
                    for strategy in ["self_correction", "majority_voting"]:
                        self.run_condition(
                            model_name, model_state,
                            fault_type=ft, injection_rate=0.3,
                            strategy=strategy, tasks=mvp_tasks,
                        )
        self.tracker.print_summary()
        return self.tracker
