"""
fault_injector.py  (v2 – research grade)
=========================================
Intercepts tool outputs and injects one of three fault types at a
configurable injection rate.  Design merges the proposal's three fault
categories with mathematically rigorous perturbation logic.

Fault types
-----------
NULL_RETURN         Tool returns None / empty – simulates API timeout.
WRONG_OUTPUT        Tool returns plausible but numerically / semantically
                    wrong data (+/-25 % perturbation on every numeric field,
                    booleans flipped, string fields swapped from a pool).
BAD_FORMAT          Tool returns structurally broken data (5 strategies:
                    truncate, unclosed JSON, XML, key=value plain text,
                    double-encoded string).

Injection rate
--------------
`injection_rate` in [0, 1] controls the probability each call is faulted.
Use 0.0 for clean baseline, 0.3 / 0.7 for partial-fault sweeps, 1.0 for
deterministic fault-injection experiments.

Usage
-----
    from src.tools.fault_injector import FaultInjector, FaultConfig, FaultType

    cfg = FaultConfig(fault_type=FaultType.WRONG_OUTPUT, injection_rate=0.7)
    fi  = FaultInjector(cfg)
    faulty_calc = fi.wrap(calculator)
    result = faulty_calc(expression="2+2")      # 70 % chance of wrong answer
"""

from __future__ import annotations

import copy
import enum
import json
import random
from dataclasses import dataclass, field
from typing import Any, Callable


# ---------------------------------------------------------------------------
# Enums & config
# ---------------------------------------------------------------------------

class FaultType(str, enum.Enum):
    NONE         = "none"
    NULL_RETURN  = "null_return"
    WRONG_OUTPUT = "wrong_output"         # was "hallucinated_output" in v1
    BAD_FORMAT   = "bad_format"           # was "wrong_format" in v1

    # legacy aliases (backward-compatible with v1 code)
    HALLUCINATED_OUTPUT = "wrong_output"
    WRONG_FORMAT        = "bad_format"


@dataclass
class FaultConfig:
    fault_type: FaultType = FaultType.NONE
    injection_rate: float = 1.0           # 0.0 = never, 1.0 = always
    seed: int = 42
    perturbation_pct: float = 0.25        # ± 25 % for WRONG_OUTPUT numerics


# ---------------------------------------------------------------------------
# Null-return pool
# ---------------------------------------------------------------------------

_NULL_VARIANTS: list[Any] = [
    None,
    "None",
    "null",
    "{}",
    "[]",
    "",
    {"success": True, "result": None},
    {"success": True, "results": []},
    {"data": None, "status": "ok"},
]

# ---------------------------------------------------------------------------
# Wrong-output string pools
# ---------------------------------------------------------------------------

_WEATHER_CONDITIONS = [
    "Raining Upward", "Fog of War", "Horizontal Hail",
    "Purple Sky", "Negative Sunshine", "Thunderless Thunder",
]
_TIERS  = ["invisible", "ghost", "quantum", "inverse"]
_STATUS = ["haunted", "schrödinger", "maybe", "unknown_unknown"]


def _perturb_value(v: Any, rng: random.Random, pct: float) -> Any:
    """Recursively perturb a JSON-compatible value."""
    if isinstance(v, float):
        sign = 1 if rng.random() > 0.5 else -1
        return round(v * (1 + sign * pct * rng.uniform(0.5, 1.5)), 6)
    if isinstance(v, int) and not isinstance(v, bool):
        delta = max(1, int(abs(v) * pct))
        sign = 1 if rng.random() > 0.5 else -1
        return v + sign * delta
    if isinstance(v, bool):
        return not v
    if isinstance(v, str):
        # Swap known semantic fields
        if v in ("Sunny", "Rainy", "Cloudy", "Windy", "Clear", "Foggy",
                 "Partly Cloudy", "Overcast", "Drizzle", "Thunderstorms", "Snow"):
            return rng.choice(_WEATHER_CONDITIONS)
        if v in ("bronze", "silver", "gold", "platinum"):
            return rng.choice(_TIERS)
        if v in ("pending", "shipped", "delivered", "cancelled"):
            return rng.choice(_STATUS)
        return v  # leave other strings untouched
    if isinstance(v, dict):
        return {k: _perturb_value(val, rng, pct) for k, val in v.items()}
    if isinstance(v, list):
        return [_perturb_value(item, rng, pct) for item in v]
    return v


def _perturb_result(result: dict, rng: random.Random, pct: float) -> dict:
    """Create a wrong-output version of a clean tool result."""
    out = copy.deepcopy(result)
    if isinstance(out.get("data"), dict):
        out["data"] = _perturb_value(out["data"], rng, pct)
    out["_fault"] = "wrong_output"
    return out


# ---------------------------------------------------------------------------
# Bad-format strategies
# ---------------------------------------------------------------------------

def _bad_format(result: dict, rng: random.Random) -> Any:
    """Apply one of 5 format-breaking strategies."""
    strategy = rng.randint(0, 4)
    text = json.dumps(result)

    if strategy == 0:
        # Truncate mid-string
        cut = max(5, int(len(text) * rng.uniform(0.2, 0.6)))
        return {"status": "ok", "data": text[:cut], "tool": result.get("tool", ""),
                "_fault": "bad_format"}

    elif strategy == 1:
        # Remove closing brackets (unclosed JSON)
        n_remove = rng.randint(1, 3)
        for ch in ('}', ']') * n_remove:
            text = text[:text.rfind(ch)] if ch in text else text
        return {"status": "ok", "data": text, "tool": result.get("tool", ""),
                "_fault": "bad_format"}

    elif strategy == 2:
        # Convert to ad-hoc XML
        def _to_xml(obj: Any, tag: str = "item") -> str:
            if isinstance(obj, dict):
                inner = "".join(_to_xml(v, k) for k, v in obj.items())
                return f"<{tag}>{inner}</{tag}>"
            if isinstance(obj, list):
                return "".join(_to_xml(i, "entry") for i in obj)
            return f"<{tag}>{obj}</{tag}>"
        xml_str = _to_xml(result.get("data", {}), "result")
        return {"status": "ok", "data": xml_str, "tool": result.get("tool", ""),
                "_fault": "bad_format"}

    elif strategy == 3:
        # key=value plain text
        def _to_kv(obj: Any, prefix: str = "") -> list[str]:
            if isinstance(obj, dict):
                lines = []
                for k, v in obj.items():
                    lines.extend(_to_kv(v, f"{prefix}{k}."))
                return lines
            return [f"{prefix.rstrip('.')}={obj}"]
        kv = "\n".join(_to_kv(result.get("data", {})))
        return {"status": "ok", "data": kv, "tool": result.get("tool", ""),
                "_fault": "bad_format"}

    else:
        # Double JSON-encode (stringified JSON inside a JSON string)
        inner = json.dumps(result.get("data", {}))
        return {"status": "ok", "data": json.dumps(inner),
                "tool": result.get("tool", ""), "_fault": "bad_format"}


# ---------------------------------------------------------------------------
# FaultInjector
# ---------------------------------------------------------------------------

class FaultInjector:
    """
    Wraps a tool callable.  Each call is independently sampled: with
    probability `config.injection_rate` the output is replaced by the
    configured fault; otherwise the real output passes through.

    Parameters
    ----------
    config : FaultConfig  – fault type, rate, seed, perturbation %.
    """

    def __init__(self, config: FaultConfig | None = None, **kwargs) -> None:
        if config is None:
            # backward-compat: accept keyword args
            ft = kwargs.get("fault_type", FaultType.NONE)
            ir = kwargs.get("fault_rate", kwargs.get("injection_rate", 1.0))
            seed = kwargs.get("seed", 42)
            config = FaultConfig(fault_type=FaultType(ft), injection_rate=ir, seed=seed)
        self.config = config
        self._rng = random.Random(config.seed)

    # ------------------------------------------------------------------
    def inject(self, tool_name: str, real_result: dict) -> dict:
        """Return a faulted version of `real_result`."""
        ft = self.config.fault_type

        if ft == FaultType.NONE:
            return real_result

        if ft == FaultType.NULL_RETURN:
            null_val = self._rng.choice(_NULL_VARIANTS)
            return {"status": "ok", "data": null_val,
                    "tool": tool_name, "_fault": "null_return"}

        if ft in (FaultType.WRONG_OUTPUT, FaultType.HALLUCINATED_OUTPUT):
            return _perturb_result(real_result, self._rng, self.config.perturbation_pct)

        if ft in (FaultType.BAD_FORMAT, FaultType.WRONG_FORMAT):
            return _bad_format(real_result, self._rng)

        return real_result

    # ------------------------------------------------------------------
    def wrap(self, tool_fn: Callable[..., dict]) -> Callable[..., dict]:
        """
        Return a new callable that passes `tool_fn`'s output through the
        fault injector at `config.injection_rate` probability.
        """
        fi = self

        def _wrapped(*args: Any, **kwargs: Any) -> dict:
            real = tool_fn(*args, **kwargs)
            if fi.config.fault_type == FaultType.NONE:
                return real
            if fi._rng.random() < fi.config.injection_rate:
                return fi.inject(real.get("tool", tool_fn.__name__), real)
            return real

        _wrapped.__name__ = tool_fn.__name__
        _wrapped.__doc__  = tool_fn.__doc__
        _wrapped.fault_config = fi.config           # type: ignore[attr-defined]
        return _wrapped

    # ------------------------------------------------------------------
    @staticmethod
    def wrap_registry(
        registry: dict[str, Callable],
        fault_type: FaultType | str,
        injection_rate: float = 1.0,
        seed: int = 42,
    ) -> dict[str, Callable]:
        """Wrap every tool in a registry dict."""
        cfg = FaultConfig(fault_type=FaultType(fault_type),
                          injection_rate=injection_rate, seed=seed)
        fi = FaultInjector(cfg)
        return {name: fi.wrap(fn) for name, fn in registry.items()}


# ---------------------------------------------------------------------------
# Output quality detector (used by recovery strategies & metrics)
# ---------------------------------------------------------------------------

def is_faulty_output(tool_result: Any) -> tuple[bool, str]:
    """
    Heuristic: decide if `tool_result` looks wrong.
    Returns (is_faulty: bool, reason: str).

    Checks in order:
      1. Not a dict
      2. Explicit _fault tag
      3. status == "error"
      4. data is None / wrong type
      5. Tool-specific sanity checks (weather temps, calculator magnitude, DB IDs)
    """
    if tool_result is None:
        return True, "Tool returned None"
    if not isinstance(tool_result, dict):
        return True, f"Expected dict, got {type(tool_result).__name__}"
    if "_fault" in tool_result:
        return True, f"Fault tag present: {tool_result['_fault']}"
    if tool_result.get("status") == "error":
        err = tool_result.get("data", {})
        if isinstance(err, dict):
            err = err.get("error", "unknown error")
        return True, f"Tool reported error: {err}"

    data = tool_result.get("data")
    if data is None:
        return True, "data payload is None"
    if not isinstance(data, dict):
        return True, f"data payload has wrong type: {type(data).__name__}"

    tool = tool_result.get("tool", "")

    if tool == "weather_lookup":
        temp = data.get("temperature_f", 0)
        hum  = data.get("humidity_pct", 50)
        cond = data.get("condition", "")
        if not (-60 <= temp <= 140):
            return True, f"Implausible temperature: {temp}°F"
        if not (0 <= hum <= 100):
            return True, f"Implausible humidity: {hum}%"
        if cond in _WEATHER_CONDITIONS:          # hallmark of wrong_output
            return True, f"Implausible weather condition: {cond}"

    if tool == "calculator":
        res = data.get("result")
        if res is not None:
            try:
                if abs(float(res)) > 1e12:
                    return True, f"Calculator result too large: {res}"
            except (TypeError, ValueError):
                return True, f"Calculator result not numeric: {res}"

    if tool == "database_query":
        rows = data.get("rows", [])
        if not isinstance(rows, list):
            return True, "database rows is not a list"
        for row in rows:
            if isinstance(row, dict) and row.get("id", 0) < 0:
                return True, "Negative row IDs detected (wrong_output)"

    return False, "ok"
