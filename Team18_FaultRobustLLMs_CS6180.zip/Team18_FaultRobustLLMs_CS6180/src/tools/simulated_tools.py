"""
simulated_tools.py
==================
Four mocked / deterministic tools used throughout the agent pipeline.
All tools return a dict with a standard envelope:
    {"status": "ok" | "error", "data": <payload>, "tool": "<name>"}

No real API calls are made — results are looked up from static tables or
evaluated locally so experiments are fully reproducible.
"""

from __future__ import annotations
import math
import re
from typing import Any

# ---------------------------------------------------------------------------
# 1. Weather Lookup
# ---------------------------------------------------------------------------

# Static weather table keyed by (city_lower, date_lower)
# date can be "today", "tomorrow", or "YYYY-MM-DD
_WEATHER_DB: dict[tuple[str, str], dict] = {}

# Pre-populate with a handful of realistic entries
_CITIES = ["new york", "boston", "london", "chicago", "los angeles",
           "seattle", "miami", "austin", "denver", "toronto"]
_CONDITIONS = ["Sunny", "Partly Cloudy", "Overcast", "Rainy", "Thunderstorms",
               "Snow", "Foggy", "Windy", "Clear", "Drizzle"]
_TEMPS_F = [28, 34, 38, 42, 55, 61, 67, 72, 78, 85, 91, 95]

import random as _random
_rng = _random.Random(42)   # fixed seed → reproducible

for _city in _CITIES:
    for _day_label in ["today", "tomorrow", "2024-12-01", "2024-12-02",
                       "2025-01-15", "2025-06-01"]:
        _temp = _rng.choice(_TEMPS_F)
        _WEATHER_DB[(_city, _day_label)] = {
            "city": _city.title(),
            "date": _day_label,
            "temperature_f": _temp,
            "temperature_c": round((_temp - 32) * 5 / 9, 1),
            "condition": _rng.choice(_CONDITIONS),
            "humidity_pct": _rng.randint(30, 90),
            "wind_mph": _rng.randint(0, 30),
        }


def weather_lookup(city: str, date: str = "today") -> dict[str, Any]:
    """
    Returns weather information for a given city and date.

    Parameters
    ----------
    city : str   – city name, e.g. "New York"
    date : str   – "today", "tomorrow", or ISO date "YYYY-MM-DD"

    Returns
    -------
    dict  {"status": "ok", "data": {...weather fields...}, "tool": "weather_lookup"}
    """
    key = (city.lower().strip(), date.lower().strip())
    if key in _WEATHER_DB:
        return {"status": "ok", "data": _WEATHER_DB[key], "tool": "weather_lookup"}
    # Fallback: generate deterministic but plausible data
    _h = abs(hash(key)) % len(_TEMPS_F)
    temp = _TEMPS_F[_h]
    return {
        "status": "ok",
        "data": {
            "city": city.title(),
            "date": date,
            "temperature_f": temp,
            "temperature_c": round((temp - 32) * 5 / 9, 1),
            "condition": _CONDITIONS[_h % len(_CONDITIONS)],
            "humidity_pct": 50 + (_h % 40),
            "wind_mph": _h % 25,
        },
        "tool": "weather_lookup",
    }


# ---------------------------------------------------------------------------
# 2. Calculator
# ---------------------------------------------------------------------------

_SAFE_NAMES = {
    k: v for k, v in math.__dict__.items() if not k.startswith("_")
}
_SAFE_NAMES.update({"abs": abs, "round": round, "int": int, "float": float})


def calculator(expression: str) -> dict[str, Any]:
    """
    Safely evaluates a mathematical expression string.

    Parameters
    ----------
    expression : str  – e.g. "15 * 47.50 / 100"  or  "sqrt(144) + 3"

    Returns
    -------
    dict  {"status": "ok", "data": {"expression": ..., "result": <float>}, "tool": "calculator"}
    """
    # Strip any markdown code fences or whitespace
    expr = expression.strip().strip("`").strip()
    # Allow only safe characters: digits, operators, parens, dot, letters (for math funcs)
    if not re.match(r'^[0-9 +\-*/().%^e,a-zA-Z_]+$', expr):
        return {"status": "error",
                "data": {"expression": expr, "error": "Unsafe expression rejected"},
                "tool": "calculator"}
    try:
        result = eval(expr, {"__builtins__": {}}, _SAFE_NAMES)  # noqa: S307
        return {
            "status": "ok",
            "data": {"expression": expr, "result": round(float(result), 6)},
            "tool": "calculator",
        }
    except Exception as exc:
        return {"status": "error",
                "data": {"expression": expr, "error": str(exc)},
                "tool": "calculator"}


# ---------------------------------------------------------------------------
# 3. Database Query
# ---------------------------------------------------------------------------

_DB_TABLES: dict[str, list[dict]] = {
    "customers": [
        {"id": i, "name": f"Customer_{i}", "email": f"customer{i}@example.com",
         "tier": ["bronze", "silver", "gold", "platinum"][i % 4],
         "total_spend": round(100 + i * 37.5, 2)}
        for i in range(1, 51)
    ],
    "products": [
        {"id": i, "name": f"Product_{i}", "category": ["electronics", "clothing",
                                                         "books", "home"][i % 4],
         "price": round(9.99 + i * 4.5, 2), "stock": (i * 7) % 200}
        for i in range(1, 51)
    ],
    "orders": [
        {"id": i, "customer_id": (i % 50) + 1, "product_id": (i % 50) + 1,
         "quantity": (i % 5) + 1, "status": ["pending", "shipped",
                                              "delivered", "cancelled"][i % 4]}
        for i in range(1, 101)
    ],
}


def database_query(table: str, filters: dict[str, Any] | None = None,
                   limit: int = 5) -> dict[str, Any]:
    """
    Queries a simulated in-memory database.

    Parameters
    ----------
    table   : str   – "customers", "products", or "orders"
    filters : dict  – key/value pairs to filter rows (exact match per field)
    limit   : int   – max number of rows to return (default 5)

    Returns
    -------
    dict  {"status": "ok", "data": {"rows": [...], "count": int}, "tool": "database_query"}
    """
    table = table.lower().strip()
    if table not in _DB_TABLES:
        return {
            "status": "error",
            "data": {"error": f"Table '{table}' not found. "
                              f"Available: {list(_DB_TABLES.keys())}"},
            "tool": "database_query",
        }

    rows = _DB_TABLES[table]
    if filters:
        for key, val in filters.items():
            rows = [r for r in rows if str(r.get(key, "")).lower() == str(val).lower()]

    rows = rows[:max(1, int(limit))]
    return {
        "status": "ok",
        "data": {"rows": rows, "count": len(rows), "table": table},
        "tool": "database_query",
    }


# ---------------------------------------------------------------------------
# 4. Web Search
# ---------------------------------------------------------------------------

_SEARCH_INDEX: dict[str, list[dict]] = {
    "ai": [
        {"title": "Latest Advances in Generative AI – MIT News",
         "url": "https://news.mit.edu/ai", "snippet": "MIT researchers publish new findings on LLM scaling laws."},
        {"title": "OpenAI releases GPT-5 technical report",
         "url": "https://openai.com/research", "snippet": "The report details training methodology and benchmark performance."},
    ],
    "climate": [
        {"title": "IPCC Sixth Assessment Report Summary",
         "url": "https://ipcc.ch/report/ar6", "snippet": "Global temperatures projected to rise 1.5°C by 2040."},
        {"title": "Carbon capture technology reaches new milestone",
         "url": "https://nature.com/carbon-capture", "snippet": "A new direct-air capture plant opens in Iceland."},
    ],
    "python": [
        {"title": "Python 3.13 Release Notes – python.org",
         "url": "https://python.org/3.13", "snippet": "New features include improved error messages and a faster CPython."},
        {"title": "Real Python: Async IO in Python: A Complete Walkthrough",
         "url": "https://realpython.com/async-io-python", "snippet": "Comprehensive tutorial on asyncio for beginners and experts."},
    ],
    "stock": [
        {"title": "S&P 500 closes at record high – Reuters",
         "url": "https://reuters.com/markets", "snippet": "The index gained 1.2% driven by tech sector earnings."},
        {"title": "How to read a stock chart – Investopedia",
         "url": "https://investopedia.com/stock-charts", "snippet": "Step-by-step guide to candlestick and OHLC charts."},
    ],
    "default": [
        {"title": "Search result 1 – Example.com",
         "url": "https://example.com/1", "snippet": "A relevant result for your query."},
        {"title": "Search result 2 – Example.org",
         "url": "https://example.org/2", "snippet": "Another useful result."},
    ],
}


def web_search(query: str, num_results: int = 3) -> dict[str, Any]:
    """
    Returns simulated web search results for a query.

    Parameters
    ----------
    query       : str – natural-language search query
    num_results : int – number of results to return (default 3)

    Returns
    -------
    dict  {"status": "ok", "data": {"results": [...], "query": str}, "tool": "web_search"}
    """
    q_lower = query.lower()
    results: list[dict] = []
    for keyword, entries in _SEARCH_INDEX.items():
        if keyword in q_lower:
            results.extend(entries)
    if not results:
        results = _SEARCH_INDEX["default"]

    results = results[:max(1, int(num_results))]
    return {
        "status": "ok",
        "data": {"results": results, "query": query, "total_found": len(results)},
        "tool": "web_search",
    }


# ---------------------------------------------------------------------------
# Registry  –  maps tool name (str) → callable
# ---------------------------------------------------------------------------

TOOL_REGISTRY: dict[str, Any] = {
    "weather_lookup": weather_lookup,
    "calculator": calculator,
    "database_query": database_query,
    "web_search": web_search,
}

# ---------------------------------------------------------------------------
# JSON Schemas  –  used to build the system prompt for the agent
# ---------------------------------------------------------------------------

TOOL_SCHEMAS: list[dict] = [
    {
        "name": "weather_lookup",
        "description": "Get current or forecasted weather for a city.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name, e.g. 'New York'"},
                "date": {"type": "string",
                         "description": "'today', 'tomorrow', or ISO date 'YYYY-MM-DD'",
                         "default": "today"},
            },
            "required": ["city"],
        },
    },
    {
        "name": "calculator",
        "description": "Evaluate a mathematical expression and return the numeric result.",
        "parameters": {
            "type": "object",
            "properties": {
                "expression": {"type": "string",
                               "description": "Math expression, e.g. '15 * 47.50 / 100'"},
            },
            "required": ["expression"],
        },
    },
    {
        "name": "database_query",
        "description": "Query the internal database for customers, products, or orders.",
        "parameters": {
            "type": "object",
            "properties": {
                "table": {"type": "string",
                          "enum": ["customers", "products", "orders"],
                          "description": "Table to query"},
                "filters": {"type": "object",
                            "description": "Key-value pairs for exact-match filtering",
                            "default": {}},
                "limit": {"type": "integer",
                          "description": "Max rows to return", "default": 5},
            },
            "required": ["table"],
        },
    },
    {
        "name": "web_search",
        "description": "Search the web and return a list of relevant results.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string",
                          "description": "Natural-language search query"},
                "num_results": {"type": "integer",
                                "description": "Number of results to return", "default": 3},
            },
            "required": ["query"],
        },
    },
]
