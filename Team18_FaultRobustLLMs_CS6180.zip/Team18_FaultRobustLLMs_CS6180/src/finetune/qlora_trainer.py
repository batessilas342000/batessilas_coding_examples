"""
qlora_trainer.py
================
QLoRA fine-tuning setup for Gemma 2B and Phi-3 Mini using
HuggingFace PEFT + bitsandbytes + TRL SFTTrainer.

Usage
-----
    trainer = QLoRATrainer(
        model_type="gemma",
        hf_model_id="google/gemma-2b-it",
        output_dir="./checkpoints/gemma-2b-qlora",
    )
    trainer.load_model_and_tokenizer()
    train_ds, eval_ds = prepare_dataset("gemma", trainer.tokenizer)
    trainer.train(train_ds, eval_ds)
    trainer.save_adapter()
"""

from __future__ import annotations

import os
from typing import Any

# All heavy imports are deferred so the module can be imported without GPU
_DEPS_LOADED = False


def _load_deps() -> None:
    global torch, transformers, peft, bitsandbytes, trl, _DEPS_LOADED
    import torch
    import transformers
    import peft
    import bitsandbytes
    import trl
    _DEPS_LOADED = True


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def get_bnb_config() -> "BitsAndBytesConfig":  # type: ignore[name-defined]
    """4-bit NF4 quantisation config."""
    from transformers import BitsAndBytesConfig
    import torch
    return BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )


def get_peft_config(model_type: str) -> "LoraConfig":  # type: ignore[name-defined]
    """
    LoRA config tuned for each model architecture.

    Gemma 2B and Phi-3 Mini both use standard transformer attention
    so we target the same projection matrices.
    """
    from peft import LoraConfig, TaskType

    target_modules = [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ]
    # Phi-3 uses slightly different naming in some versions
    if model_type == "phi3":
        target_modules = [
            "qkv_proj", "o_proj",
            "gate_up_proj", "down_proj",
        ]

    return LoraConfig(
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        target_modules=target_modules,
        bias="none",
        task_type=TaskType.CAUSAL_LM,
    )


# ---------------------------------------------------------------------------
# QLoRATrainer
# ---------------------------------------------------------------------------

class QLoRATrainer:
    """
    Wraps model loading, PEFT setup, and SFT training into one class.

    Parameters
    ----------
    model_type   : "gemma" | "phi3"
    hf_model_id  : HuggingFace model identifier
    output_dir   : where to save checkpoints and the final adapter
    wandb_project: W&B project name (set to None to disable logging)
    """

    MODEL_DEFAULTS = {
        "gemma": {
            "hf_id": "google/gemma-2b-it",
            "max_seq_length": 1024,
        },
        "phi3": {
            "hf_id": "microsoft/Phi-3-mini-4k-instruct",
            "max_seq_length": 1024,
        },
    }

    def __init__(
        self,
        model_type: str,
        hf_model_id: str | None = None,
        output_dir: str = "./checkpoints",
        wandb_project: str | None = "cs6180-final-project",
        num_train_epochs: int = 3,
        per_device_batch_size: int = 4,
        gradient_accumulation_steps: int = 4,
        learning_rate: float = 2e-4,
        max_seq_length: int = 1024,
        seed: int = 42,
    ) -> None:
        self.model_type = model_type
        defaults = self.MODEL_DEFAULTS.get(model_type, {})
        self.hf_model_id = hf_model_id or defaults.get("hf_id", "")
        self.output_dir = output_dir
        self.wandb_project = wandb_project
        self.num_train_epochs = num_train_epochs
        self.per_device_batch_size = per_device_batch_size
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.learning_rate = learning_rate
        self.max_seq_length = max_seq_length or defaults.get("max_seq_length", 1024)
        self.seed = seed

        self.model = None
        self.tokenizer = None
        self._peft_model = None

    # ------------------------------------------------------------------
    def load_model_and_tokenizer(self) -> None:
        """Load the base model in 4-bit and configure the tokenizer."""
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM

        print(f"Loading tokenizer: {self.hf_model_id}")
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.hf_model_id,
            trust_remote_code=True,
        )
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "right"  # avoids warnings with some models

        bnb_config = get_bnb_config()
        print(f"Loading model: {self.hf_model_id} (4-bit NF4)")
        self.model = AutoModelForCausalLM.from_pretrained(
            self.hf_model_id,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
            attn_implementation="eager",  # safer than flash-attn on Colab
        )
        self.model.config.use_cache = False           # required for gradient checkpointing
        self.model.config.pretraining_tp = 1
        print("Model loaded successfully.")

    # ------------------------------------------------------------------
    def prepare_peft_model(self) -> None:
        """Wrap the loaded model with LoRA adapters."""
        from peft import get_peft_model, prepare_model_for_kbit_training

        if self.model is None:
            raise RuntimeError("Call load_model_and_tokenizer() first.")

        # Prepare for k-bit training (freezes non-LoRA params, adds cast hooks)
        self.model = prepare_model_for_kbit_training(self.model)
        peft_config = get_peft_config(self.model_type)
        self._peft_model = get_peft_model(self.model, peft_config)
        self._peft_model.print_trainable_parameters()

    # ------------------------------------------------------------------
    def train(
        self,
        train_dataset: Any,
        eval_dataset: Any,
    ) -> None:
        """
        Fine-tune the model with SFTTrainer.

        Parameters
        ----------
        train_dataset : HF Dataset with columns: input_ids, attention_mask, labels
        eval_dataset  : HF Dataset (same format)
        """
        from transformers import TrainingArguments
        from trl import SFTTrainer, DataCollatorForCompletionOnlyLM

        if self._peft_model is None:
            self.prepare_peft_model()

        # Configure W&B logging
        if self.wandb_project:
            os.environ["WANDB_PROJECT"] = self.wandb_project

        training_args = TrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=self.num_train_epochs,
            per_device_train_batch_size=self.per_device_batch_size,
            per_device_eval_batch_size=self.per_device_batch_size,
            gradient_accumulation_steps=self.gradient_accumulation_steps,
            learning_rate=self.learning_rate,
            lr_scheduler_type="cosine",
            warmup_ratio=0.03,
            weight_decay=0.001,
            optim="paged_adamw_32bit",
            bf16=True,
            fp16=False,
            logging_steps=25,
            eval_strategy="steps",
            eval_steps=100,
            save_strategy="steps",
            save_steps=200,
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            report_to="wandb" if self.wandb_project else "none",
            run_name=f"{self.model_type}-qlora-tool-calling",
            seed=self.seed,
            dataloader_num_workers=0,
            remove_unused_columns=False,
        )

        trainer = SFTTrainer(
            model=self._peft_model,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            tokenizer=self.tokenizer,
            args=training_args,
            max_seq_length=self.max_seq_length,
            dataset_text_field=None,  # already tokenized
            packing=False,
        )

        print(f"Starting QLoRA fine-tuning for {self.model_type}…")
        trainer.train()
        print("Training complete.")
        self._trainer = trainer

    # ------------------------------------------------------------------
    def save_adapter(self, path: str | None = None) -> str:
        """Save only the LoRA adapter weights (small, ~50 MB)."""
        save_path = path or os.path.join(self.output_dir, "final_adapter")
        if self._peft_model is not None:
            self._peft_model.save_pretrained(save_path)
        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(save_path)
        print(f"Adapter saved to: {save_path}")
        return save_path

    # ------------------------------------------------------------------
    def load_adapter(self, adapter_path: str) -> None:
        """
        Load a previously saved adapter on top of the (already loaded)
        base model.
        """
        from peft import PeftModel

        if self.model is None:
            self.load_model_and_tokenizer()

        print(f"Loading adapter from: {adapter_path}")
        self._peft_model = PeftModel.from_pretrained(self.model, adapter_path)
        self._peft_model.eval()
        print("Adapter loaded.")

    # ------------------------------------------------------------------
    def merge_adapter(self, save_path: str | None = None) -> str:
        """
        Merge the LoRA adapter weights into the base model and save the
        merged checkpoint.  The merged model runs without PEFT overhead
        and is faster at inference time.

        This creates a NEW directory — the original base model is unchanged.
        """
        if self._peft_model is None:
            raise RuntimeError("No adapter loaded.  Call train() or load_adapter() first.")

        save_path = save_path or os.path.join(self.output_dir, "merged_model")
        print(f"Merging adapter into base model → {save_path}")

        merged = self._peft_model.merge_and_unload()
        merged.save_pretrained(save_path)
        if self.tokenizer is not None:
            self.tokenizer.save_pretrained(save_path)
        print(f"Merged model saved to: {save_path}")
        return save_path

    # ------------------------------------------------------------------
    def get_training_history(self) -> list[dict]:
        """Return per-step training log from the SFTTrainer (if available)."""
        if hasattr(self, "_trainer") and self._trainer is not None:
            return self._trainer.state.log_history
        return []

    # ------------------------------------------------------------------
    @property
    def active_model(self) -> Any:
        """Return the PEFT model if available, else the base model."""
        return self._peft_model if self._peft_model is not None else self.model
