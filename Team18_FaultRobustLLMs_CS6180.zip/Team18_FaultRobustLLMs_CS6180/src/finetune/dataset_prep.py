"""
dataset_prep.py
===============
Loads and formats the glaive-function-calling-v2 dataset for
QLoRA fine-tuning of Gemma 2B and Phi-3 Mini.

The glaive dataset has these columns:
    system  – system message describing available functions (JSON)
    chat    – alternating HUMAN/GLAIVE turns including function calls

We reformat each example into the target model's chat template.

Reference: https://huggingface.co/datasets/glaive-ai/glaive-function-calling-v2
"""

from __future__ import annotations

import json
import re
from typing import Any

# Deferred imports (not available in all environments)
try:
    from datasets import load_dataset, Dataset
    _HF_DATASETS_OK = True
except ImportError:
    _HF_DATASETS_OK = False


# ---------------------------------------------------------------------------
# Glaive dataset parser
# ---------------------------------------------------------------------------

def _parse_glaive_chat(system_text: str, chat_text: str) -> list[dict[str, str]]:
    """
    Convert a glaive-function-calling-v2 example into a standard
    list of {"role": ..., "content": ...} message dicts.

    Glaive format uses:
        SYSTEM: <functions block>
        HUMAN: <user message>
        GLAIVE: <assistant response, possibly with <functioncall> XML>
        FUNCTION RESPONSE: <tool output>
    """
    messages: list[dict[str, str]] = []

    # System message  ─────────────────────────────────────────────────
    if system_text and system_text.strip():
        messages.append({"role": "system", "content": system_text.strip()})

    # Parse turns  ────────────────────────────────────────────────────
    # Split on role markers
    turn_pattern = re.compile(
        r'(HUMAN:|GLAIVE:|FUNCTION RESPONSE:)',
        re.IGNORECASE,
    )
    parts = turn_pattern.split(chat_text)

    i = 0
    while i < len(parts):
        part = parts[i].strip()
        if part.upper() in ("HUMAN:", "HUMAN"):
            if i + 1 < len(parts):
                content = parts[i + 1].strip()
                if content:
                    messages.append({"role": "user", "content": content})
                i += 2
            else:
                i += 1
        elif part.upper() in ("GLAIVE:", "GLAIVE"):
            if i + 1 < len(parts):
                content = parts[i + 1].strip()
                if content:
                    # Convert <functioncall> XML tags → JSON tool_call format
                    content = _convert_functioncall_to_json(content)
                    messages.append({"role": "assistant", "content": content})
                i += 2
            else:
                i += 1
        elif part.upper() in ("FUNCTION RESPONSE:", "FUNCTION RESPONSE"):
            if i + 1 < len(parts):
                content = parts[i + 1].strip()
                if content:
                    messages.append({"role": "tool", "content": content})
                i += 2
            else:
                i += 1
        else:
            i += 1

    return messages


def _convert_functioncall_to_json(text: str) -> str:
    """
    Replace glaive's <functioncall>...</functioncall> XML tags with
    our standard JSON tool_call format.

    Input:  <functioncall> {"name": "get_weather", "arguments": {...}} </functioncall>
    Output: ```json\n{"tool_call": {"name": "get_weather", "arguments": {...}}}\n```
    """
    pattern = re.compile(r'<functioncall>\s*(.*?)\s*</functioncall>', re.DOTALL)

    def _replace(m: re.Match) -> str:
        inner = m.group(1).strip()
        try:
            obj = json.loads(inner)
            if "name" in obj:
                new_obj = {
                    "tool_call": {
                        "name": obj["name"],
                        "arguments": obj.get("arguments", obj.get("parameters", {})),
                    }
                }
                return "```json\n" + json.dumps(new_obj, indent=2) + "\n```"
        except json.JSONDecodeError:
            pass
        return inner  # fallback: return raw

    return pattern.sub(_replace, text)


# ---------------------------------------------------------------------------
# Chat-template formatters per model
# ---------------------------------------------------------------------------

def format_for_gemma(
    messages: list[dict[str, str]],
    tokenizer: Any,
    max_length: int = 1024,
) -> dict[str, Any]:
    """
    Apply Gemma 2B instruct chat template and tokenize.
    Gemma does NOT support 'system' or 'tool' roles:
    - system → folded into first user message as a prefix
    - tool   → converted to a user turn
    """
    system_text = ""
    cleaned = []
    for msg in messages:
        role = msg["role"]
        if role == "system":
            system_text = msg["content"]
        elif role == "tool":
            cleaned.append({"role": "user",
                             "content": f"[Tool Result]\n{msg['content']}"})
        else:
            cleaned.append(msg)

    # Prepend system text to first user message
    if system_text and cleaned:
        for i, msg in enumerate(cleaned):
            if msg["role"] == "user":
                cleaned[i] = {
                    "role": "user",
                    "content": system_text + "\n\n" + msg["content"],
                }
                break

    if not cleaned:
        return {"input_ids": [], "attention_mask": [], "labels": []}

    text = tokenizer.apply_chat_template(
        cleaned, tokenize=False, add_generation_prompt=False
    )
    tokenized = tokenizer(
        text,
        max_length=max_length,
        truncation=True,
        padding=False,
        return_tensors=None,
    )
    tokenized["labels"] = tokenized["input_ids"].copy()
    return tokenized


def format_for_phi3(
    messages: list[dict[str, str]],
    tokenizer: Any,
    max_length: int = 1024,
) -> dict[str, Any]:
    """
    Apply Phi-3 Mini instruct chat template and tokenize.
    Phi-3 supports the 'tool' role natively via <|tool|> tokens.
    """
    text = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=False
    )
    tokenized = tokenizer(
        text,
        max_length=max_length,
        truncation=True,
        padding=False,
        return_tensors=None,
    )
    tokenized["labels"] = tokenized["input_ids"].copy()
    return tokenized


# ---------------------------------------------------------------------------
# Dataset class and main prepare function
# ---------------------------------------------------------------------------

class GlaiveFunctionCallingDataset:
    """
    Thin wrapper around the HuggingFace glaive-function-calling-v2 dataset.

    Parameters
    ----------
    num_train   : int  – number of training examples to use
    num_eval    : int  – number of evaluation examples
    seed        : int  – random seed for shuffling
    """

    HF_DATASET_ID = "glaiveai/glaive-function-calling-v2"

    def __init__(
        self,
        num_train: int = 5000,
        num_eval: int = 500,
        seed: int = 42,
    ) -> None:
        if not _HF_DATASETS_OK:
            raise ImportError("Install 'datasets': pip install datasets")
        self.num_train = num_train
        self.num_eval = num_eval
        self.seed = seed
        self._raw = None

    def load(self) -> "GlaiveFunctionCallingDataset":
        """Download (or use cache) the raw dataset."""
        print(f"Loading {self.HF_DATASET_ID} …")
        ds = load_dataset(self.HF_DATASET_ID, split="train")
        ds = ds.shuffle(seed=self.seed)
        total = self.num_train + self.num_eval
        self._raw = ds.select(range(min(total, len(ds))))
        print(f"Loaded {len(self._raw)} examples")
        return self

    def get_train_eval_split(self) -> tuple["Dataset", "Dataset"]:
        if self._raw is None:
            self.load()
        train = self._raw.select(range(self.num_train))
        eval_ = self._raw.select(range(self.num_train,
                                       min(self.num_train + self.num_eval,
                                           len(self._raw))))
        return train, eval_


def prepare_dataset(
    model_type: str,
    tokenizer: Any,
    num_train: int = 5000,
    num_eval: int = 500,
    max_seq_length: int = 1024,
    seed: int = 42,
) -> tuple["Dataset", "Dataset"]:
    """
    Load glaive-function-calling-v2 and return (train_dataset, eval_dataset)
    formatted for `model_type` ("gemma" or "phi3").

    Each example in the returned datasets has keys:
        input_ids, attention_mask, labels
    """
    glaive = GlaiveFunctionCallingDataset(
        num_train=num_train, num_eval=num_eval, seed=seed
    )
    raw_train, raw_eval = glaive.get_train_eval_split()

    format_fn = format_for_gemma if model_type == "gemma" else format_for_phi3

    def _process(example: dict) -> dict:
        try:
            messages = _parse_glaive_chat(
                example.get("system", ""),
                example.get("chat", ""),
            )
            if not messages:
                return {"input_ids": [], "attention_mask": [], "labels": []}
            return format_fn(messages, tokenizer, max_length=max_seq_length)
        except Exception:
            return {"input_ids": [], "attention_mask": [], "labels": []}

    print(f"Tokenizing training set ({len(raw_train)} examples)…")
    train_tok = raw_train.map(_process, remove_columns=raw_train.column_names,
                               desc="Tokenizing train")

    print(f"Tokenizing eval set ({len(raw_eval)} examples)…")
    eval_tok = raw_eval.map(_process, remove_columns=raw_eval.column_names,
                              desc="Tokenizing eval")

    # Remove empty examples (failed parse)
    train_tok = train_tok.filter(lambda x: len(x["input_ids"]) > 10)
    eval_tok = eval_tok.filter(lambda x: len(x["input_ids"]) > 10)

    print(f"Final: {len(train_tok)} train / {len(eval_tok)} eval examples")
    return train_tok, eval_tok
