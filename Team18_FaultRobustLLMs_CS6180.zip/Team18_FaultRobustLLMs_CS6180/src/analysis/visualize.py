"""
visualize.py  (v2 – research grade)
======================================
All figures and tables for the NeurIPS-format report.

Figures
-------
 Fig 1 – Accuracy heatmap: 4 checkpoints × 3 fault types  (at injection_rate=0.3)
 Fig 2 – Accuracy vs. injection rate (0 → 30 % → 70 %) per fault type — line chart
 Fig 3 – Recovery strategy comparison: none / SC / MV grouped bars
 Fig 4 – Fine-tuning delta: Δaccuracy and Δrecovery_rate (base → finetuned)
 Fig 5 – Forgetting table: MMLU / ARC / GSM8K accuracy before & after fine-tuning
 Fig 6 – Failure mode stacked bar: silent_wrong / explicit_error /
          hallucinated_fix / correct_refusal / success
 Fig 7 – Per-category accuracy breakdown (weather / math / database / search)
 Fig 8 – Fault detection & false alarm rates

Tables
------
 Table 1 – Full numeric results (LaTeX-ready CSV)
 Table 2 – Best strategy per condition
 Table 3 – Statistical significance summary
"""

from __future__ import annotations

import json
import os
from typing import Any

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
import seaborn as sns

matplotlib.rcParams.update({
    "font.family": "sans-serif",
    "font.size":   11,
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "figure.dpi": 150,
    "savefig.bbox": "tight",
    "savefig.dpi": 200,
})

# ── Colour / label maps ───────────────────────────────────────────────────────
MODEL_LABELS = {
    "gemma":      "Gemma 2B",
    "gemma-2b":   "Gemma 2B",
    "phi3":       "Phi-3 Mini",
    "phi3-mini":  "Phi-3 Mini",
}
STATE_LABELS  = {"base": "Base", "finetuned": "Fine-tuned"}
FAULT_LABELS  = {
    "none":         "No Fault",
    "null_return":  "Null Return",
    "wrong_output": "Wrong Output",
    "bad_format":   "Bad Format",
    # v1 compat
    "hallucinated_output": "Wrong Output",
    "wrong_format":        "Bad Format",
}
STRAT_LABELS  = {
    "none":             "No Recovery",
    "self_correction":  "Self-Correction",
    "majority_voting":  "Majority Voting",
}
FAILURE_COLORS = {
    "success":           "#2ca02c",
    "silent_wrong":      "#d62728",
    "explicit_error":    "#ff7f0e",
    "hallucinated_fix":  "#9467bd",
    "correct_refusal":   "#1f77b4",
}
PALETTE_MODELS = {"gemma": "#4C72B0", "phi3": "#DD8452",
                  "gemma-2b": "#4C72B0", "phi3-mini": "#DD8452"}
PALETTE_STRAT  = {"self_correction": "#1f77b4",
                  "majority_voting": "#ff7f0e",
                  "none": "#999999"}


def _model_state_label(row: Any) -> str:
    m = MODEL_LABELS.get(str(row["model_name"]), row["model_name"])
    s = STATE_LABELS.get(str(row["model_state"]), row["model_state"])
    return f"{m}\n({s})"


class ResultsVisualizer:
    def __init__(
        self,
        results_dir:  str = "./results",
        figures_dir:  str = "./results/figures",
    ) -> None:
        self.results_dir = results_dir
        self.figures_dir = figures_dir
        os.makedirs(figures_dir, exist_ok=True)
        self.raw: pd.DataFrame | None = None
        self.agg: pd.DataFrame | None = None
        self.stat_tests: dict = {}

    # ------------------------------------------------------------------
    def load(self, raw_path=None, agg_path=None, stat_path=None) -> "ResultsVisualizer":
        raw_path  = raw_path  or os.path.join(self.results_dir, "raw_results.csv")
        agg_path  = agg_path  or os.path.join(self.results_dir, "aggregate_metrics.csv")
        stat_path = stat_path or os.path.join(self.results_dir, "statistical_tests.json")
        self.raw = pd.read_csv(raw_path)
        self.agg = pd.read_csv(agg_path)
        if os.path.exists(stat_path):
            with open(stat_path) as f:
                self.stat_tests = json.load(f)
        print(f"Loaded {len(self.raw)} raw, {len(self.agg)} aggregate rows.")
        return self

    def load_from_tracker(self, tracker: Any) -> "ResultsVisualizer":
        self.raw = tracker.to_dataframe()
        self.agg = tracker.aggregate()
        self.stat_tests = tracker.statistical_tests()
        return self

    def _save(self, fig: plt.Figure, name: str) -> str:
        path = os.path.join(self.figures_dir, name)
        fig.savefig(path)
        plt.close(fig)
        print(f"Saved: {path}")
        return path

    # ──────────────────────────────────────────────────────────────────
    # Fig 1: Accuracy heatmap (4 checkpoints × 3 fault types)
    # ──────────────────────────────────────────────────────────────────
    def plot_accuracy_heatmap(self, injection_rate: float = 0.3) -> str:
        assert self.agg is not None
        fault_order = ["null_return", "wrong_output", "bad_format"]
        df = self.agg[
            (self.agg["fault_type"].isin(fault_order))
            & (self.agg["injection_rate"] == injection_rate)
        ].copy()
        df["checkpoint"] = df.apply(_model_state_label, axis=1)

        # Use best recovery per checkpoint × fault
        df["accuracy"] = pd.to_numeric(df["accuracy"], errors="coerce")
        best = df.groupby(["checkpoint", "fault_type"])["accuracy"].max().reset_index()
        pivot = best.pivot(index="fault_type", columns="checkpoint", values="accuracy")
        pivot = pivot.reindex([FAULT_LABELS.get(f, f) for f in fault_order]
                              if all(FAULT_LABELS.get(f, f) in pivot.index for f in fault_order)
                              else fault_order)
        # relabel
        pivot.index = [FAULT_LABELS.get(idx, idx) for idx in pivot.index]

        fig, ax = plt.subplots(figsize=(11, 4))
        sns.heatmap(pivot, ax=ax, annot=True, fmt=".2f",
                    vmin=0.0, vmax=1.0, cmap="RdYlGn",
                    linewidths=0.5, cbar_kws={"label": "Accuracy"})
        ax.set_title(
            f"Answer Accuracy by Checkpoint & Fault Type  (injection rate = {injection_rate:.0%})",
            fontweight="bold",
        )
        ax.set_xlabel("Checkpoint")
        ax.set_ylabel("Fault Type")
        return self._save(fig, "fig1_accuracy_heatmap.png")

    # ──────────────────────────────────────────────────────────────────
    # Fig 2: Accuracy vs. injection rate – line charts
    # ──────────────────────────────────────────────────────────────────
    def plot_accuracy_vs_rate(self) -> str:
        assert self.agg is not None
        fault_order = ["null_return", "wrong_output", "bad_format"]
        df = self.agg[self.agg["fault_type"].isin(fault_order)].copy()
        df["accuracy"] = pd.to_numeric(df["accuracy"], errors="coerce")
        df["checkpoint"] = df.apply(_model_state_label, axis=1)

        fig, axes = plt.subplots(1, 3, figsize=(15, 5), sharey=True)
        for ax, fault in zip(axes, fault_order):
            sub = df[df["fault_type"] == fault]
            for cp in sorted(sub["checkpoint"].unique()):
                grp = sub[sub["checkpoint"] == cp].groupby("injection_rate")["accuracy"].max()
                rates = sorted(grp.index.tolist())
                # prepend 0.0 (clean baseline)
                clean = self.agg[
                    (self.agg["fault_type"] == "none")
                    & (self.agg.apply(_model_state_label, axis=1) == cp)
                ]["accuracy"].mean()
                x = [0.0] + rates
                y = [clean] + [grp.get(r, np.nan) for r in rates]
                ax.plot(x, y, marker="o", label=cp)
            ax.set_title(FAULT_LABELS.get(fault, fault), fontweight="bold")
            ax.set_xlabel("Injection Rate")
            ax.set_xticks([0.0, 0.3, 0.7])
            ax.set_xticklabels(["0%", "30%", "70%"])
            ax.set_ylim(0, 1.05)
        axes[0].set_ylabel("Accuracy")
        axes[0].legend(fontsize=8, loc="lower left")
        fig.suptitle("Accuracy vs. Injection Rate by Fault Type",
                     fontsize=14, fontweight="bold")
        return self._save(fig, "fig2_accuracy_vs_rate.png")

    # ──────────────────────────────────────────────────────────────────
    # Fig 3: Recovery strategy comparison
    # ──────────────────────────────────────────────────────────────────
    def plot_strategy_comparison(self, injection_rate: float = 0.3) -> str:
        assert self.agg is not None
        fault_order = ["null_return", "wrong_output", "bad_format"]
        df = self.agg[
            (self.agg["fault_type"].isin(fault_order))
            & (self.agg["injection_rate"] == injection_rate)
        ].copy()
        df["accuracy"]   = pd.to_numeric(df["accuracy"], errors="coerce")
        df["checkpoint"] = df.apply(_model_state_label, axis=1)
        df["strategy"]   = df["recovery_strategy"].map(STRAT_LABELS)

        fig, axes = plt.subplots(1, 3, figsize=(15, 5), sharey=True)
        for ax, fault in zip(axes, fault_order):
            sub = df[df["fault_type"] == fault]
            sns.barplot(data=sub, x="checkpoint", y="accuracy", hue="strategy",
                        ax=ax, palette=list(PALETTE_STRAT.values())[:3])
            ax.set_title(FAULT_LABELS.get(fault, fault), fontweight="bold")
            ax.set_xlabel("")
            ax.set_ylim(0, 1.05)
            ax.tick_params(axis="x", rotation=20)
        axes[0].set_ylabel("Accuracy")
        fig.suptitle(
            f"Recovery Strategy Comparison  (injection rate = {injection_rate:.0%})",
            fontsize=14, fontweight="bold",
        )
        return self._save(fig, "fig3_strategy_comparison.png")

    # ──────────────────────────────────────────────────────────────────
    # Fig 4: Fine-tuning delta
    # ──────────────────────────────────────────────────────────────────
    def plot_finetuning_delta(self) -> str:
        assert self.agg is not None
        keys = ["model_name", "fault_type", "injection_rate", "recovery_strategy"]
        base = self.agg[self.agg["model_state"] == "base"]
        ft   = self.agg[self.agg["model_state"] == "finetuned"]
        merged = base.merge(ft, on=keys, suffixes=("_base", "_ft"))
        for col in ["accuracy", "recovery_rate"]:
            merged[f"{col}_base"] = pd.to_numeric(merged[f"{col}_base"], errors="coerce")
            merged[f"{col}_ft"]   = pd.to_numeric(merged[f"{col}_ft"],   errors="coerce")
        merged["acc_delta"] = merged["accuracy_ft"] - merged["accuracy_base"]
        merged["rr_delta"]  = merged["recovery_rate_ft"] - merged["recovery_rate_base"]

        fault_order = ["none", "null_return", "wrong_output", "bad_format"]
        merged["fault_label"] = merged["fault_type"].map(FAULT_LABELS)
        merged["model_label"] = merged["model_name"].map(MODEL_LABELS)

        fig, axes = plt.subplots(1, 2, figsize=(13, 5))
        for ax, col, title in [
            (axes[0], "acc_delta",  "Accuracy Δ  (Fine-tuned − Base)"),
            (axes[1], "rr_delta",   "Recovery Rate Δ  (Fine-tuned − Base)"),
        ]:
            sns.barplot(data=merged[merged["fault_type"].isin(fault_order)],
                        x="fault_label", y=col, hue="model_label",
                        ax=ax, palette=list(PALETTE_MODELS.values())[:2])
            ax.axhline(0, color="black", linewidth=0.8, linestyle="--")
            ax.set_xlabel("Fault Type")
            ax.set_ylabel(col.replace("_", " ").title())
            ax.set_title(title, fontweight="bold")
            ax.tick_params(axis="x", rotation=15)
        fig.suptitle("Effect of QLoRA Fine-Tuning on Robustness",
                     fontsize=14, fontweight="bold")
        return self._save(fig, "fig4_finetuning_delta.png")

    # ──────────────────────────────────────────────────────────────────
    # Fig 5: Forgetting table
    # ──────────────────────────────────────────────────────────────────
    def plot_forgetting_table(self, forgetting_data: dict) -> str:
        """
        forgetting_data: dict returned by ForgettingBenchmark.compute_forgetting_deltas()
        Shape: {"mmlu": {"base_accuracy": ..., "finetuned_accuracy": ..., "delta": ..., ...}, ...}
        """
        rows = []
        for bench, vals in forgetting_data.items():
            if not isinstance(vals, dict):
                continue
            rows.append({
                "Benchmark": bench.upper().replace("_", "-"),
                "Base": f"{vals.get('base_accuracy', 0):.1%}",
                "Fine-tuned": f"{vals.get('finetuned_accuracy', 0):.1%}",
                "Δ": f"{vals.get('delta', 0):+.1%}",
                "Significant Drop": "✓" if vals.get("significant_drop") else "",
            })
        if not rows:
            return ""

        df_table = pd.DataFrame(rows)
        fig, ax = plt.subplots(figsize=(8, len(rows) * 0.8 + 1.5))
        ax.axis("off")
        tbl = ax.table(
            cellText=df_table.values, colLabels=df_table.columns,
            cellLoc="center", loc="center",
        )
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(11)
        tbl.scale(1.2, 1.8)
        # Colour negative deltas red
        for i, row in enumerate(rows):
            try:
                delta_val = float(row["Δ"].replace("%", "").replace("+", "")) / 100
                if delta_val < -0.03:
                    tbl[i + 1, 3].set_facecolor("#ffcccc")
            except ValueError:
                pass
        ax.set_title("Catastrophic Forgetting Evaluation", fontweight="bold", pad=12)
        return self._save(fig, "fig5_forgetting_table.png")

    # ──────────────────────────────────────────────────────────────────
    # Fig 6: Failure mode stacked bar
    # ──────────────────────────────────────────────────────────────────
    def plot_failure_modes(self, injection_rate: float = 0.3) -> str:
        assert self.agg is not None
        fault_order = ["null_return", "wrong_output", "bad_format"]
        df = self.agg[
            (self.agg["fault_type"].isin(fault_order))
            & (self.agg["injection_rate"] == injection_rate)
        ].copy()
        df["checkpoint"] = df.apply(_model_state_label, axis=1)
        # Average across strategies per checkpoint × fault
        mode_cols = ["pct_success", "pct_silent_wrong", "pct_explicit_error",
                     "pct_hallucinated_fix", "pct_correct_refusal"]
        for c in mode_cols:
            df[c] = pd.to_numeric(df[c], errors="coerce")

        grouped = df.groupby(["checkpoint", "fault_type"])[mode_cols].mean().reset_index()
        grouped["fault_label"] = grouped["fault_type"].map(FAULT_LABELS)
        grouped["x_label"] = grouped["checkpoint"] + "\n" + grouped["fault_label"]

        fig, ax = plt.subplots(figsize=(14, 5))
        x = np.arange(len(grouped))
        bottom = np.zeros(len(grouped))
        mode_display = {
            "pct_success":          ("Success",           FAILURE_COLORS["success"]),
            "pct_silent_wrong":     ("Silent Wrong",      FAILURE_COLORS["silent_wrong"]),
            "pct_explicit_error":   ("Explicit Error",    FAILURE_COLORS["explicit_error"]),
            "pct_hallucinated_fix": ("Hallucinated Fix",  FAILURE_COLORS["hallucinated_fix"]),
            "pct_correct_refusal":  ("Correct Refusal",   FAILURE_COLORS["correct_refusal"]),
        }
        for col, (label, colour) in mode_display.items():
            vals = grouped[col].fillna(0).values
            ax.bar(x, vals, bottom=bottom, color=colour, label=label, width=0.7)
            bottom += vals

        ax.set_xticks(x)
        ax.set_xticklabels(grouped["x_label"], fontsize=8, rotation=30, ha="right")
        ax.set_ylabel("Fraction of Queries")
        ax.set_ylim(0, 1.05)
        ax.set_title(f"Failure Mode Distribution  (injection rate = {injection_rate:.0%})",
                     fontweight="bold")
        ax.legend(loc="upper right", fontsize=9)
        return self._save(fig, "fig6_failure_modes.png")

    # ──────────────────────────────────────────────────────────────────
    # Fig 7: Per-category accuracy
    # ──────────────────────────────────────────────────────────────────
    def plot_per_category(self, injection_rate: float = 0.3) -> str:
        assert self.raw is not None
        if "category" not in self.raw.columns:
            print("No 'category' column, skipping Fig 7.")
            return ""
        fault_order = ["null_return", "wrong_output", "bad_format"]
        df = self.raw[
            (self.raw["fault_type"].isin(fault_order))
            & (self.raw["injection_rate"].astype(float) == injection_rate)
        ].copy()
        df["answer_correct"] = df["answer_correct"].astype(int)
        df["checkpoint"] = df["model_name"].map(MODEL_LABELS) + "\n(" + df["model_state"] + ")"

        cats = ["weather", "math", "database", "search"]
        fig, axes = plt.subplots(2, 2, figsize=(12, 9))
        for ax, cat in zip(axes.flatten(), cats):
            sub = df[df["category"] == cat]
            acc = sub.groupby(["checkpoint", "fault_type"])["answer_correct"].mean().reset_index()
            acc["fault_label"] = acc["fault_type"].map(FAULT_LABELS)
            sns.barplot(data=acc, x="fault_label", y="answer_correct",
                        hue="checkpoint", ax=ax, palette="Set2")
            ax.set_title(f"{cat.title()} Queries", fontweight="bold")
            ax.set_xlabel("Fault Type")
            ax.set_ylabel("Accuracy")
            ax.set_ylim(0, 1.05)
            ax.tick_params(axis="x", rotation=12)
        fig.suptitle("Per-Category Accuracy by Fault Type",
                     fontsize=14, fontweight="bold")
        return self._save(fig, "fig7_per_category.png")

    # ──────────────────────────────────────────────────────────────────
    # Fig 8: Fault detection & false alarm rates
    # ──────────────────────────────────────────────────────────────────
    def plot_detection_rates(self, injection_rate: float = 0.3) -> str:
        assert self.agg is not None
        df = self.agg[
            (self.agg["fault_type"] != "none")
            & (self.agg["recovery_strategy"] == "self_correction")
            & (self.agg["injection_rate"] == injection_rate)
        ].copy()
        for c in ["fault_detection_rate", "false_alarm_rate"]:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df["checkpoint"]   = df.apply(_model_state_label, axis=1)
        df["fault_label"]  = df["fault_type"].map(FAULT_LABELS)

        fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharey=True)
        for ax, col, title, colour in [
            (axes[0], "fault_detection_rate", "Fault Detection Rate (Self-Correction)", "#2ca02c"),
            (axes[1], "false_alarm_rate",     "False Alarm Rate (Self-Correction)",     "#d62728"),
        ]:
            sns.barplot(data=df, x="fault_label", y=col, hue="checkpoint",
                        ax=ax, palette="Set1")
            ax.set_title(title, fontweight="bold")
            ax.set_xlabel("Fault Type")
            ax.set_ylabel(col.replace("_", " ").title())
            ax.set_ylim(0, 1.05)
            ax.tick_params(axis="x", rotation=12)
        fig.suptitle("Self-Correction: Detection Quality",
                     fontsize=14, fontweight="bold")
        return self._save(fig, "fig8_detection_rates.png")

    # ──────────────────────────────────────────────────────────────────
    # Tables
    # ──────────────────────────────────────────────────────────────────
    def make_table1(self) -> pd.DataFrame:
        assert self.agg is not None
        cols = ["model_name", "model_state", "fault_type", "injection_rate",
                "recovery_strategy", "accuracy", "tool_selection_accuracy",
                "recovery_rate", "fault_detection_rate", "false_alarm_rate",
                "avg_retries", "avg_latency_ms"]
        t1 = self.agg[[c for c in cols if c in self.agg.columns]].copy()
        for c in ["accuracy", "tool_selection_accuracy",
                  "recovery_rate", "fault_detection_rate", "false_alarm_rate"]:
            if c in t1:
                t1[c] = pd.to_numeric(t1[c], errors="coerce")
                t1[c] = t1[c].apply(lambda x: f"{x:.1%}" if pd.notna(x) else "—")
        path = os.path.join(self.results_dir, "table1_full_results.csv")
        t1.to_csv(path, index=False)
        print(f"Saved Table 1: {path}")
        return t1

    def make_table2(self) -> pd.DataFrame:
        assert self.agg is not None
        subset = self.agg[self.agg["fault_type"] != "none"].copy()
        subset["accuracy"] = pd.to_numeric(subset["accuracy"], errors="coerce")
        idx = subset.groupby(["model_name", "model_state", "fault_type",
                               "injection_rate"])["accuracy"].idxmax()
        t2 = subset.loc[idx].copy()
        path = os.path.join(self.results_dir, "table2_best_strategy.csv")
        t2.to_csv(path, index=False)
        print(f"Saved Table 2: {path}")
        return t2

    def make_table3_stats(self) -> pd.DataFrame:
        """Statistical significance summary table."""
        if not self.stat_tests:
            print("No statistical tests available.")
            return pd.DataFrame()
        rows = []
        for key, result in self.stat_tests.items():
            if not isinstance(result, dict):
                continue
            rows.append({
                "comparison": key,
                "test": result.get("test", ""),
                "statistic": result.get("statistic"),
                "p_value": result.get("p_value"),
                "significant": result.get("significant", False),
                "mean_a": result.get("mean_a"),
                "mean_b": result.get("mean_b"),
            })
        df = pd.DataFrame(rows)
        path = os.path.join(self.results_dir, "table3_statistical_tests.csv")
        df.to_csv(path, index=False)
        print(f"Saved Table 3: {path}")
        return df

    # ──────────────────────────────────────────────────────────────────
    def make_all(self, forgetting_data: dict | None = None) -> None:
        print("\nGenerating all figures and tables …\n")
        self.plot_accuracy_heatmap()
        self.plot_accuracy_vs_rate()
        self.plot_strategy_comparison()
        self.plot_finetuning_delta()
        if forgetting_data:
            self.plot_forgetting_table(forgetting_data)
        self.plot_failure_modes()
        self.plot_per_category()
        self.plot_detection_rates()
        self.make_table1()
        self.make_table2()
        self.make_table3_stats()
        print("\nAll outputs saved.")
