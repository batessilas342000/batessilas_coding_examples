"""
prompts.py
==========
System prompts and message formatters for the tool-calling agent.

Both Gemma 2B and Phi-3 Mini use different chat templates, so we
build the final prompt strings here and apply them via the model's
tokenizer.apply_chat_template() method in the pipeline.
"""

from __future__ import annotations
import json
from typing import Any


# ---------------------------------------------------------------------------
# System prompt builder
# ---------------------------------------------------------------------------

SYSTEM_PROMPT_TEMPLATE = """\
You are a helpful assistant that can use tools to answer user questions.

## Available Tools
{tool_schemas}

## Instructions
When you need to use a tool, respond with a JSON object in this EXACT format:
```json
{{
  "tool_call": {{
    "name": "<tool_name>",
    "arguments": {{
      "<param1>": "<value1>",
      "<param2>": "<value2>"
    }}
  }}
}}
```

Rules:
1. ONLY output a tool call JSON if you need to call a tool.
2. AFTER receiving the tool result, give a clear natural-language answer.
3. If the tool result looks wrong, empty, or malformed, say so and explain what you expected.
4. Do NOT make up answers — use the tool output.
5. If you cannot answer with the available tools, say "I cannot answer this question with the available tools."

## Tool Schemas (JSON)
{tool_schemas_json}
"""


def build_system_prompt(tool_schemas: list[dict]) -> str:
    """
    Build the system prompt string by injecting tool schema information.

    Parameters
    ----------
    tool_schemas : list[dict]
        List of tool schema dicts (as defined in simulated_tools.TOOL_SCHEMAS).

    Returns
    -------
    str  – formatted system prompt
    """
    # Human-readable summary
    readable_lines = []
    for schema in tool_schemas:
        params = schema.get("parameters", {}).get("properties", {})
        required = schema.get("parameters", {}).get("required", [])
        param_strs = []
        for pname, pinfo in params.items():
            req_tag = " [required]" if pname in required else " [optional]"
            param_strs.append(f"    - {pname} ({pinfo.get('type','any')}){req_tag}: "
                              f"{pinfo.get('description','')}")
        params_text = "\n".join(param_strs) if param_strs else "    (no parameters)"
        readable_lines.append(
            f"### {schema['name']}\n"
            f"  Description: {schema['description']}\n"
            f"  Parameters:\n{params_text}"
        )
    tool_schemas_readable = "\n\n".join(readable_lines)
    tool_schemas_json = json.dumps(tool_schemas, indent=2)

    return SYSTEM_PROMPT_TEMPLATE.format(
        tool_schemas=tool_schemas_readable,
        tool_schemas_json=tool_schemas_json,
    )


# ---------------------------------------------------------------------------
# Recovery prompt snippets
# ---------------------------------------------------------------------------

SELF_CORRECTION_PROMPT = """\
The previous tool call returned a result that appears to be incorrect or malformed.

Previous tool result:
{bad_result}

Problem detected: {problem_description}

Please try calling the tool again. You may need to adjust the arguments \
or try a different approach. Retry {retry_num} of {max_retries}."""


def build_self_correction_message(
    bad_result: Any,
    problem_description: str,
    retry_num: int,
    max_retries: int,
) -> str:
    """Build the self-correction prompt injected before a retry."""
    return SELF_CORRECTION_PROMPT.format(
        bad_result=json.dumps(bad_result, indent=2, default=str),
        problem_description=problem_description,
        retry_num=retry_num,
        max_retries=max_retries,
    )


MAJORITY_VOTING_PROMPT = """\
I need you to call the appropriate tool to answer this question. \
Please make a tool call now. This is sample {sample_num} of {total_samples}."""


def build_majority_voting_message(sample_num: int, total_samples: int) -> str:
    return MAJORITY_VOTING_PROMPT.format(
        sample_num=sample_num, total_samples=total_samples
    )


# ---------------------------------------------------------------------------
# Tool result formatter (adds the result back into the conversation)
# ---------------------------------------------------------------------------

def format_tool_result_for_context(
    tool_name: str,
    tool_result: Any,
    is_faulty: bool = False,
    fault_reason: str = "",
) -> str:
    """
    Format a tool result as the 'tool' turn in the conversation.
    We label clearly if the result looks faulty so the model can reason about it.
    """
    result_str = json.dumps(tool_result, indent=2, default=str)
    if is_faulty:
        header = f"[TOOL: {tool_name}] ⚠ POTENTIALLY FAULTY RESULT ({fault_reason})\n"
    else:
        header = f"[TOOL: {tool_name}] Result:\n"
    return header + result_str


# ---------------------------------------------------------------------------
# Chat template helpers (model-specific)
# ---------------------------------------------------------------------------

def apply_chat_template_gemma(
    tokenizer: Any,
    messages: list[dict[str, str]],
    add_generation_prompt: bool = True,
) -> str:
    """Apply Gemma 2B instruct chat template.
    Gemma does not support the 'system' role — fold any system message
    into the first user turn as a prefix.
    Gemma also requires strictly alternating user/assistant roles —
    merge consecutive same-role messages.
    """
    cleaned = []
    system_text = ""
    for msg in messages:
        if msg["role"] == "system":
            system_text = msg["content"]
        else:
            cleaned.append(msg)

    # Prepend system text to the first user message
    if system_text and cleaned:
        for i, msg in enumerate(cleaned):
            if msg["role"] == "user":
                cleaned[i] = {
                    "role": "user",
                    "content": system_text + "\n\n" + msg["content"],
                }
                break

    # Merge consecutive same-role messages (Gemma requires strict alternation)
    merged = []
    for msg in cleaned:
        if merged and merged[-1]["role"] == msg["role"]:
            merged[-1] = {
                "role": msg["role"],
                "content": merged[-1]["content"] + "\n\n" + msg["content"],
            }
        else:
            merged.append(dict(msg))

    return tokenizer.apply_chat_template(
        merged,
        tokenize=False,
        add_generation_prompt=add_generation_prompt,
    )


def apply_chat_template_phi3(
    tokenizer: Any,
    messages: list[dict[str, str]],
    add_generation_prompt: bool = True,
) -> str:
    """Apply Phi-3 Mini instruct chat template."""
    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=add_generation_prompt,
    )


def apply_chat_template(
    model_type: str,
    tokenizer: Any,
    messages: list[dict[str, str]],
    add_generation_prompt: bool = True,
) -> str:
    """
    Dispatch to the correct chat template function based on model_type.

    Parameters
    ----------
    model_type : str  – "gemma" or "phi3"
    """
    if model_type == "gemma":
        return apply_chat_template_gemma(tokenizer, messages, add_generation_prompt)
    elif model_type == "phi3":
        return apply_chat_template_phi3(tokenizer, messages, add_generation_prompt)
    else:
        # fallback: let tokenizer decide
        return tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=add_generation_prompt
        )
