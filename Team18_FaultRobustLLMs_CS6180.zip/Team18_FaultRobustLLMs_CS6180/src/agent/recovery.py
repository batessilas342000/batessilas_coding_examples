"""
recovery.py  (v2 – research grade)
====================================
Two recovery strategies, both upgraded for publication-quality evaluation.

SelfCorrectionRecovery
    One-turn verdict: model emits {"verdict": "ok|retry", "reason": ...,
    "new_tool": ..., "new_args": ...}.  Tracks fault_detected and
    false_alarm separately from correctness.

MajorityVotingRecovery
    Calls the tool k times (default 3).  Aggregates results:
      – numeric scalar  → median
      – list of dicts   → mode (most frequent JSON-serialised value)
      – string          → mode
    Also records model-choice votes for analysis.
"""

from __future__ import annotations

import collections
import copy
import json
import statistics
from typing import Any, Callable

from .prompts import build_self_correction_message
from ..tools.fault_injector import is_faulty_output


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_numeric(tool_result: Any) -> float | None:
    """Pull the primary numeric value out of a tool result dict."""
    if not isinstance(tool_result, dict):
        return None
    data = tool_result.get("data")
    if not isinstance(data, dict):
        return None
    tool = tool_result.get("tool", "")
    if tool == "calculator":
        try:
            return float(data.get("result", 0))
        except (TypeError, ValueError):
            return None
    if tool == "weather_lookup":
        try:
            return float(data.get("temperature_f", 0))
        except (TypeError, ValueError):
            return None
    return None


def _result_key(tool_result: Any) -> str:
    """Stable hash key for a tool result (for mode calculation)."""
    try:
        data = tool_result.get("data") if isinstance(tool_result, dict) else tool_result
        return json.dumps(data, sort_keys=True, default=str)
    except Exception:
        return str(tool_result)


class RecoveryStrategy:
    name: str = "base"

    def recover(self, *args: Any, **kwargs: Any) -> dict:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# 1. Self-Correction Recovery
# ---------------------------------------------------------------------------

_SC_VERDICT_PROMPT = """\
You just called a tool and received this result:

{tool_result_json}

Question: Does this result look correct and complete for the original task?

Respond ONLY with a JSON object in one of these two shapes:

Shape A (result looks OK):
{{
  "verdict": "ok",
  "final_answer": "<your answer to the user based on this result>"
}}

Shape B (result looks wrong or empty):
{{
  "verdict": "retry",
  "reason": "<brief explanation of what looks wrong>",
  "new_tool": "<tool name to call>",
  "new_args": {{<new arguments>}}
}}
"""


class SelfCorrectionRecovery(RecoveryStrategy):
    """
    Ask the model to verify the tool output in a single turn.
    Tracks fault_detected (model said "retry") and false_alarm (model said
    "retry" on a clean result) as first-class metrics.

    Parameters
    ----------
    generate_fn        : fn(messages, temperature) -> str
    tool_executor_fn   : fn(tool_name, args) -> dict
    parse_tool_call_fn : fn(raw_text) -> (tool_name, args) | None
    max_retries        : int
    """

    name = "self_correction"

    def __init__(
        self,
        generate_fn: Callable,
        tool_executor_fn: Callable,
        parse_tool_call_fn: Callable,
        max_retries: int = 3,
    ) -> None:
        self.generate_fn       = generate_fn
        self.tool_executor_fn  = tool_executor_fn
        self.parse_tool_call_fn = parse_tool_call_fn
        self.max_retries       = max_retries

    # ------------------------------------------------------------------
    @staticmethod
    def _parse_verdict(raw: str) -> dict | None:
        """Extract the verdict JSON from model output."""
        import re
        patterns = [
            r'```(?:json)?\s*(\{.*?\})\s*```',
            r'(\{[^{}]*"verdict"[^{}]*\})',
            r'(\{.*\})',
        ]
        for pat in patterns:
            m = re.search(pat, raw, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group(1))
                except json.JSONDecodeError:
                    continue
        return None

    # ------------------------------------------------------------------
    def verify(
        self,
        messages: list[dict],
        tool_result: Any,
        original_fault_injected: bool = False,
    ) -> dict:
        """
        One-turn verification call.

        Returns
        -------
        dict:
            verdict           : "ok" | "retry" | "parse_error"
            reason            : str
            fault_detected    : bool – model said retry
            false_alarm       : bool – model said retry but result was clean
            suggested_tool    : str | None
            suggested_args    : dict | None
            raw_response      : str
        """
        prompt = _SC_VERDICT_PROMPT.format(
            tool_result_json=json.dumps(tool_result, indent=2, default=str)
        )
        verify_msgs = copy.deepcopy(messages)
        verify_msgs.append({"role": "user", "content": prompt})

        raw = self.generate_fn(verify_msgs, temperature=0.05)
        verdict_obj = self._parse_verdict(raw)

        if verdict_obj is None:
            return {
                "verdict": "parse_error",
                "reason": "could not parse verdict JSON",
                "fault_detected": False,
                "false_alarm": False,
                "suggested_tool": None,
                "suggested_args": None,
                "raw_response": raw,
            }

        verdict = verdict_obj.get("verdict", "ok").lower()
        fault_detected = (verdict == "retry")
        result_is_clean = not is_faulty_output(tool_result)[0]
        false_alarm = fault_detected and result_is_clean

        return {
            "verdict": verdict,
            "reason": verdict_obj.get("reason", ""),
            "fault_detected": fault_detected,
            "false_alarm": false_alarm,
            "suggested_tool": verdict_obj.get("new_tool"),
            "suggested_args": verdict_obj.get("new_args"),
            "final_answer_from_model": verdict_obj.get("final_answer", ""),
            "raw_response": raw,
        }

    # ------------------------------------------------------------------
    def recover(
        self,
        messages: list[dict],
        bad_tool_result: Any,
        fault_reason: str,
        original_fault_injected: bool = True,
    ) -> dict:
        """
        Iterative retry loop up to max_retries.

        Returns
        -------
        dict:
            final_result     : best tool result obtained
            recovered        : bool
            retries_used     : int
            verdicts         : list[dict]  – per-attempt SC verdict
            fault_detected   : bool – at least one SC call flagged the result
            false_alarm      : bool – SC flagged a clean result (across all attempts)
            final_messages   : list[dict]
        """
        current_msgs = copy.deepcopy(messages)
        last_result  = bad_tool_result
        verdicts: list[dict] = []
        any_detected = False
        any_false_alarm = False

        for attempt in range(1, self.max_retries + 1):
            # ── Verification turn ────────────────────────────────────────
            v = self.verify(current_msgs, last_result, original_fault_injected)
            verdicts.append(v)
            if v["fault_detected"]:
                any_detected = True
            if v["false_alarm"]:
                any_false_alarm = True

            if v["verdict"] == "ok":
                return {
                    "final_result": last_result,
                    "recovered": True,
                    "retries_used": attempt - 1,
                    "verdicts": verdicts,
                    "fault_detected": any_detected,
                    "false_alarm": any_false_alarm,
                    "final_messages": current_msgs,
                }

            # ── Retry with suggested or fresh tool call ──────────────────
            retry_tool  = v.get("suggested_tool")
            retry_args  = v.get("suggested_args") or {}

            if retry_tool:
                new_result = self.tool_executor_fn(retry_tool, retry_args)
            else:
                # Ask the model to suggest a new call
                correction_msg = build_self_correction_message(
                    bad_result=last_result,
                    problem_description=v.get("reason", fault_reason),
                    retry_num=attempt,
                    max_retries=self.max_retries,
                )
                current_msgs.append({"role": "user", "content": correction_msg})
                raw2 = self.generate_fn(current_msgs, temperature=0.1)
                current_msgs.append({"role": "assistant", "content": raw2})
                parsed = self.parse_tool_call_fn(raw2)
                if parsed is None:
                    continue
                retry_tool, retry_args = parsed
                new_result = self.tool_executor_fn(retry_tool, retry_args or {})

            is_bad, reason = is_faulty_output(new_result)
            if not is_bad:
                return {
                    "final_result": new_result,
                    "recovered": True,
                    "retries_used": attempt,
                    "verdicts": verdicts,
                    "fault_detected": any_detected,
                    "false_alarm": any_false_alarm,
                    "final_messages": current_msgs,
                }
            last_result  = new_result
            fault_reason = reason

        return {
            "final_result": last_result,
            "recovered": False,
            "retries_used": self.max_retries,
            "verdicts": verdicts,
            "fault_detected": any_detected,
            "false_alarm": any_false_alarm,
            "final_messages": current_msgs,
        }


# ---------------------------------------------------------------------------
# 2. Majority Voting Recovery
# ---------------------------------------------------------------------------

class MajorityVotingRecovery(RecoveryStrategy):
    """
    Call the tool k times (each independently subject to fault injection).
    Aggregate the outputs:
      – Numeric scalar → median (robust to outlier faults)
      – List/dict/str  → mode  (most frequent JSON-serialised value)

    Also records which (tool_name, args) pair was voted most frequently by
    the model – useful for analysis of whether fine-tuning stabilises
    tool selection.

    Parameters
    ----------
    generate_fn       : fn(messages, temperature) -> str
    tool_executor_fn  : fn(tool_name, args) -> dict
    parse_tool_call_fn: fn(raw_text) -> (tool_name, args) | None
    k                 : number of independent samples (default 3)
    temperature       : diversity temperature for model samples
    """

    name = "majority_voting"

    def __init__(
        self,
        generate_fn: Callable,
        tool_executor_fn: Callable,
        parse_tool_call_fn: Callable,
        k: int = 3,
        temperature: float = 0.8,
    ) -> None:
        self.generate_fn       = generate_fn
        self.tool_executor_fn  = tool_executor_fn
        self.parse_tool_call_fn = parse_tool_call_fn
        self.k                 = k
        self.temperature       = temperature

    # ------------------------------------------------------------------
    @staticmethod
    def _aggregate(results: list[dict]) -> dict:
        """
        Aggregate k tool results into a single consensus result.

        For numeric fields: median.
        For other fields:   mode (most common JSON value).
        """
        if not results:
            return {}
        if len(results) == 1:
            return results[0]

        # Try numeric aggregation first
        numerics = [_extract_numeric(r) for r in results]
        if all(n is not None for n in numerics):
            median_val = statistics.median(numerics)  # type: ignore[arg-type]
            # Return the result closest to the median
            best = min(results, key=lambda r: abs((_extract_numeric(r) or 0) - median_val))
            best = copy.deepcopy(best)
            best["_mv_aggregate"] = "median"
            best["_mv_k"] = len(results)
            return best

        # Mode aggregation: most common serialised output
        vote_counter: collections.Counter = collections.Counter(
            _result_key(r) for r in results
        )
        winning_key, _ = vote_counter.most_common(1)[0]
        for r in results:
            if _result_key(r) == winning_key:
                out = copy.deepcopy(r)
                out["_mv_aggregate"] = "mode"
                out["_mv_k"] = len(results)
                return out

        return results[0]

    # ------------------------------------------------------------------
    def recover(
        self,
        messages: list[dict],
    ) -> dict:
        """
        Sample the model k times, execute the tool on each chosen call,
        then aggregate the results.

        Returns
        -------
        dict:
            final_result       : aggregated tool result
            recovered          : bool (final result passes is_faulty_output)
            tool_results       : all k raw results (pre-aggregation)
            model_call_votes   : Counter of (tool_name, args_key) pairs
            winning_call       : (tool_name, args) that was most voted
            all_raw_responses  : all k model responses
            final_messages     : messages with winning call appended
        """
        tool_results: list[dict] = []
        all_raw: list[str] = []
        call_votes: collections.Counter = collections.Counter()

        for i in range(self.k):
            msgs = copy.deepcopy(messages)
            if i > 0:
                # Light diversity prompt on subsequent samples
                if msgs and msgs[-1]["role"] == "user":
                    msgs[-1] = {
                        "role": "user",
                        "content": msgs[-1]["content"]
                                   + f"\n\n(Attempt {i+1}/{self.k} — please make a tool call.)",
                    }
            raw = self.generate_fn(msgs, temperature=self.temperature if i > 0 else 0.1)
            all_raw.append(raw)
            parsed = self.parse_tool_call_fn(raw)
            if parsed is None:
                continue
            tool_name, tool_args = parsed
            vote_key = (tool_name, json.dumps(tool_args or {}, sort_keys=True, default=str))
            call_votes[vote_key] += 1
            result = self.tool_executor_fn(tool_name, tool_args or {})
            tool_results.append(result)

        if not tool_results:
            return {
                "final_result": {"status": "error",
                                 "data": {"error": "No valid tool calls produced"},
                                 "tool": "none"},
                "recovered": False,
                "tool_results": [],
                "model_call_votes": {},
                "winning_call": None,
                "all_raw_responses": all_raw,
                "final_messages": messages,
            }

        # Aggregate
        aggregated = self._aggregate(tool_results)
        faulty, _ = is_faulty_output(aggregated)

        # Determine winning model call
        winning_call = None
        if call_votes:
            (wt, wa_str), _ = call_votes.most_common(1)[0]
            winning_call = (wt, json.loads(wa_str))

        final_msgs = copy.deepcopy(messages)
        if winning_call:
            final_msgs.append({
                "role": "assistant",
                "content": json.dumps(
                    {"tool_call": {"name": winning_call[0],
                                   "arguments": winning_call[1]}}, indent=2
                ),
            })

        return {
            "final_result": aggregated,
            "recovered": not faulty,
            "tool_results": tool_results,
            "model_call_votes": dict(call_votes),
            "winning_call": winning_call,
            "all_raw_responses": all_raw,
            "final_messages": final_msgs,
        }
