"""
pipeline.py
===========
LangGraph-based agent pipeline for tool-calling with fault injection
and recovery strategy support.

Graph structure:
    START → [plan_tool_call] → [execute_tool] → [check_output]
               ↑                                        |
               |              (faulty?)                 |
               └────────── [recover] ←──────────────── |
                                                        |
                                              (clean / max retries)
                                                        ↓
                                            [generate_final_answer] → END

Each node is a Python function that takes and returns AgentState.
"""

from __future__ import annotations

import json
import re
import time
import copy
from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Optional

# LangGraph imports (gracefully handle missing dep during unit testing)
try:
    from langgraph.graph import StateGraph, END
    _LANGGRAPH_AVAILABLE = True
except ImportError:
    _LANGGRAPH_AVAILABLE = False
    END = "END"

from .prompts import (
    build_system_prompt,
    format_tool_result_for_context,
    apply_chat_template,
)
from .recovery import SelfCorrectionRecovery, MajorityVotingRecovery
from ..tools.fault_injector import is_faulty_output
from ..tools.simulated_tools import TOOL_SCHEMAS, TOOL_REGISTRY


# ---------------------------------------------------------------------------
# State definition
# ---------------------------------------------------------------------------

@dataclass
class AgentState:
    """Immutable-ish state passed between graph nodes."""
    # Conversation
    user_query: str = ""
    messages: list[dict[str, str]] = field(default_factory=list)

    # Tool execution
    tool_name: Optional[str] = None
    tool_args: Optional[dict] = None
    tool_result: Optional[Any] = None
    tool_result_is_faulty: bool = False
    fault_reason: str = ""

    # Recovery
    recovery_strategy: str = "self_correction"   # or "majority_voting"
    retries_used: int = 0
    max_retries: int = 3
    recovered: bool = False

    # Final output
    final_answer: str = ""
    raw_model_output: str = ""

    # Metrics
    start_time: float = 0.0
    end_time: float = 0.0
    latency_ms: float = 0.0
    node_trace: list[str] = field(default_factory=list)

    # Experiment metadata
    model_name: str = ""
    fault_type: str = "none"
    model_state: str = "base"        # "base" or "finetuned"

    def to_dict(self) -> dict:
        return {
            "user_query": self.user_query,
            "tool_name": self.tool_name,
            "tool_args": self.tool_args,
            "tool_result": self.tool_result,
            "tool_result_is_faulty": self.tool_result_is_faulty,
            "fault_reason": self.fault_reason,
            "recovery_strategy": self.recovery_strategy,
            "retries_used": self.retries_used,
            "recovered": self.recovered,
            "final_answer": self.final_answer,
            "latency_ms": self.latency_ms,
            "node_trace": self.node_trace,
            "model_name": self.model_name,
            "fault_type": self.fault_type,
            "model_state": self.model_state,
        }


# ---------------------------------------------------------------------------
# Tool-call parser
# ---------------------------------------------------------------------------

def _extract_json_objects(text: str) -> list[dict]:
    """Find all valid JSON objects in text by tracking brace depth."""
    objects = []
    i = 0
    while i < len(text):
        if text[i] == '{':
            depth = 0
            for j in range(i, len(text)):
                if text[j] == '{':
                    depth += 1
                elif text[j] == '}':
                    depth -= 1
                    if depth == 0:
                        candidate = text[i:j+1]
                        try:
                            objects.append(json.loads(candidate))
                        except json.JSONDecodeError:
                            pass
                        i = j
                        break
        i += 1
    return objects


def parse_tool_call(raw_text: str) -> tuple[str, dict] | None:
    """
    Extract a tool call from model output.
    Handles multiple JSON shapes including Gemma's flat format:
        {"tool_call": "<name>", "arguments": {...}}
    and the standard nested format:
        {"tool_call": {"name": "...", "arguments": {...}}}

    Returns (tool_name, args_dict) or None if no valid call found.
    """
    # Collect all JSON objects from the text using brace-depth tracking
    all_objs = _extract_json_objects(raw_text)

    # Also check inside markdown fences (insert at front — higher priority)
    for fence_match in re.finditer(r"```(?:json)?\s*(\{.*?\})\s*```", raw_text, re.DOTALL):
        try:
            all_objs.insert(0, json.loads(fence_match.group(1)))
        except Exception:
            pass

    for obj in all_objs:
        # Shape 1: {"tool_call": {"name": ..., "arguments": ...}}
        if "tool_call" in obj and isinstance(obj["tool_call"], dict):
            tc = obj["tool_call"]
            if "name" in tc:
                return tc["name"], tc.get("arguments", {})

        # Shape 4: {"tool_call": "<name>", "arguments": {...}}  (Gemma format)
        if "tool_call" in obj and isinstance(obj["tool_call"], str) and "arguments" in obj:
            return obj["tool_call"], obj.get("arguments", {})

        # Shape 2: {"name": ..., "arguments": ...}
        if "name" in obj and "arguments" in obj:
            return obj["name"], obj.get("arguments", {})

        # Shape 3: {"function_call": {"name": ..., "arguments": ...}}
        if "function_call" in obj:
            fc = obj["function_call"]
            if isinstance(fc, dict) and "name" in fc:
                args = fc.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                return fc["name"], args

    return None


# ---------------------------------------------------------------------------
# Main Pipeline class
# ---------------------------------------------------------------------------

class AgentPipeline:
    """
    A LangGraph agent pipeline with configurable fault injection and
    recovery strategy.

    Parameters
    ----------
    model_name   : str        – "gemma" or "phi3"
    model_type   : str        – same as model_name (chat template key)
    tokenizer    : HF tokenizer (or None for testing)
    model        : HF model   (or None for testing)
    tool_registry: dict       – {name: callable} possibly with fault wrapping
    system_prompt: str        – built from build_system_prompt()
    recovery_strategy : str  – "self_correction" | "majority_voting"
    max_retries  : int
    n_mv_samples : int        – samples for majority voting
    mv_temperature: float
    device       : str        – "cuda" | "cpu"
    """

    def __init__(
        self,
        model_name: str,
        model_type: str,
        tokenizer: Any,
        model: Any,
        tool_registry: dict[str, Callable] | None = None,
        system_prompt: str | None = None,
        recovery_strategy: str = "self_correction",
        max_retries: int = 3,
        n_mv_samples: int = 5,
        mv_temperature: float = 0.8,
        device: str = "cuda",
        max_new_tokens: int = 512,
    ) -> None:
        self.model_name = model_name
        self.model_type = model_type
        self.tokenizer = tokenizer
        self.model = model
        self.tool_registry = tool_registry or TOOL_REGISTRY
        self.system_prompt = system_prompt or build_system_prompt(TOOL_SCHEMAS)
        self.recovery_strategy = recovery_strategy
        self.max_retries = max_retries
        self.n_mv_samples = n_mv_samples
        self.mv_temperature = mv_temperature
        self.device = device
        self.max_new_tokens = max_new_tokens

        # Build recovery objects
        self._sc_recovery = SelfCorrectionRecovery(
            generate_fn=self._generate,
            tool_executor_fn=self._execute_tool,
            parse_tool_call_fn=parse_tool_call,
            max_retries=max_retries,
        )
        self._mv_recovery = MajorityVotingRecovery(
            generate_fn=self._generate,
            tool_executor_fn=self._execute_tool,
            parse_tool_call_fn=parse_tool_call,
            k=n_mv_samples,
            temperature=mv_temperature,
        )

    # ------------------------------------------------------------------
    # LLM generation wrapper
    # ------------------------------------------------------------------

    def _generate(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.1,
        max_new_tokens: int | None = None,
    ) -> str:
        """Generate a model response for the given message list."""
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("Model and tokenizer must be loaded before inference.")

        import torch

        max_new_tokens = max_new_tokens or self.max_new_tokens

        prompt = apply_chat_template(
            self.model_type, self.tokenizer, messages, add_generation_prompt=True
        )
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=(temperature > 0),
                temperature=temperature if temperature > 0 else 1.0,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )

        # Decode only the newly generated tokens
        input_len = inputs["input_ids"].shape[1]
        new_tokens = outputs[0][input_len:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    # ------------------------------------------------------------------
    # Tool executor
    # ------------------------------------------------------------------

    def _execute_tool(self, tool_name: str, tool_args: dict) -> dict:
        """Look up `tool_name` in the registry and call it with `tool_args`."""
        fn = self.tool_registry.get(tool_name)
        if fn is None:
            return {
                "status": "error",
                "data": {"error": f"Unknown tool: '{tool_name}'"},
                "tool": tool_name,
            }
        try:
            return fn(**tool_args)
        except TypeError as e:
            return {
                "status": "error",
                "data": {"error": f"Bad arguments for {tool_name}: {e}"},
                "tool": tool_name,
            }

    # ------------------------------------------------------------------
    # Main run method (no-graph version for simplicity & compatibility)
    # ------------------------------------------------------------------

    def run(
        self,
        user_query: str,
        fault_type: str = "none",
        model_state: str = "base",
    ) -> AgentState:
        """
        Run the full agent loop for a single query.

        1. Build initial messages
        2. Ask the model to produce a tool call
        3. Execute the tool (with possible fault injection already in registry)
        4. Apply recovery if output is faulty
        5. Generate final answer from clean (or best available) tool result

        Returns the populated AgentState with all metrics.
        """
        state = AgentState(
            user_query=user_query,
            recovery_strategy=self.recovery_strategy,
            max_retries=self.max_retries,
            model_name=self.model_name,
            fault_type=fault_type,
            model_state=model_state,
            start_time=time.time(),
        )
        state.node_trace.append("start")

        # ── Step 1: build initial conversation ──────────────────────────
        state.messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": user_query},
        ]

        # ── Step 2: model generates tool call ───────────────────────────
        state.node_trace.append("plan_tool_call")
        if self.recovery_strategy == "majority_voting":
            # For MV we run the planning step N times inside the recovery
            mv_result = self._mv_recovery.recover(messages=copy.deepcopy(state.messages))
            state.tool_result = mv_result["final_result"]
            state.recovered = mv_result["recovered"]
            winning = mv_result.get("winning_call")
            if winning:
                state.tool_name, state.tool_args = winning
            state.retries_used = 0   # no re-tries in MV; samples counted separately
            state.messages = mv_result.get("final_messages", state.messages)
            tool_result_is_faulty, fault_reason = is_faulty_output(state.tool_result)
            state.tool_result_is_faulty = tool_result_is_faulty
            state.fault_reason = fault_reason
        else:
            raw = self._generate(state.messages)
            state.raw_model_output = raw
            state.messages.append({"role": "assistant", "content": raw})
            state.node_trace.append("execute_tool")

            parsed = parse_tool_call(raw)
            if parsed is None:
                state.final_answer = (
                    "I was unable to determine which tool to use for this query."
                )
                state.end_time = time.time()
                state.latency_ms = (state.end_time - state.start_time) * 1000
                return state

            state.tool_name, state.tool_args = parsed
            state.tool_result = self._execute_tool(state.tool_name, state.tool_args or {})

            # ── Step 3: check output ─────────────────────────────────────
            faulty, reason = is_faulty_output(state.tool_result)
            state.tool_result_is_faulty = faulty
            state.fault_reason = reason

            if faulty:
                state.node_trace.append("check_output→faulty")
                # ── Step 4: self-correction recovery ────────────────────
                state.node_trace.append("recover")
                tool_result_str = format_tool_result_for_context(
                    state.tool_name, state.tool_result, is_faulty=True,
                    fault_reason=reason
                )
                state.messages.append({"role": "user", "content": tool_result_str})

                sc_result = self._sc_recovery.recover(
                    messages=copy.deepcopy(state.messages),
                    bad_tool_result=state.tool_result,
                    fault_reason=reason,
                )
                state.tool_result = sc_result["final_result"]
                state.recovered = sc_result["recovered"]
                state.retries_used = sc_result["retries_used"]
                state.messages = sc_result["final_messages"]
            else:
                state.node_trace.append("check_output→clean")

        # ── Step 5: generate final answer ───────────────────────────────
        state.node_trace.append("generate_final_answer")
        tool_result_str = format_tool_result_for_context(
            state.tool_name or "unknown",
            state.tool_result,
            is_faulty=state.tool_result_is_faulty and not state.recovered,
        )
        state.messages.append({"role": "user", "content": tool_result_str})
        final_raw = self._generate(state.messages, temperature=0.1)
        state.final_answer = final_raw
        state.messages.append({"role": "assistant", "content": final_raw})

        state.end_time = time.time()
        state.latency_ms = (state.end_time - state.start_time) * 1000
        state.node_trace.append("end")
        return state

    # ------------------------------------------------------------------
    # LangGraph graph builder (optional – used for visualization)
    # ------------------------------------------------------------------

    def build_graph(self):
        """
        Build and return a compiled LangGraph StateGraph.
        Useful for visualisation: graph.get_graph().draw_mermaid()
        """
        if not _LANGGRAPH_AVAILABLE:
            raise ImportError("langgraph is not installed. Run: pip install langgraph")

        # We wrap AgentState fields into a plain dict for LangGraph compatibility
        from typing import TypedDict

        class GraphState(TypedDict):
            messages: list[dict]
            user_query: str
            tool_name: str
            tool_args: dict
            tool_result: Any
            faulty: bool
            fault_reason: str
            retries: int
            final_answer: str

        def node_plan(state: GraphState) -> GraphState:
            msgs = state["messages"]
            raw = self._generate(msgs)
            msgs.append({"role": "assistant", "content": raw})
            parsed = parse_tool_call(raw)
            if parsed:
                state["tool_name"], state["tool_args"] = parsed
            return state

        def node_execute(state: GraphState) -> GraphState:
            result = self._execute_tool(state["tool_name"], state["tool_args"])
            state["tool_result"] = result
            faulty, reason = is_faulty_output(result)
            state["faulty"] = faulty
            state["fault_reason"] = reason
            return state

        def node_recover(state: GraphState) -> GraphState:
            state["retries"] = state.get("retries", 0) + 1
            correction = build_self_correction_message(
                bad_result=state["tool_result"],
                problem_description=state["fault_reason"],
                retry_num=state["retries"],
                max_retries=self.max_retries,
            )
            state["messages"].append({"role": "user", "content": correction})
            return node_plan(node_execute(state))

        def node_answer(state: GraphState) -> GraphState:
            tool_str = format_tool_result_for_context(
                state["tool_name"], state["tool_result"]
            )
            state["messages"].append({"role": "user", "content": tool_str})
            answer = self._generate(state["messages"])
            state["final_answer"] = answer
            return state

        def route_after_execute(state: GraphState) -> Literal["recover", "answer"]:
            if state["faulty"] and state.get("retries", 0) < self.max_retries:
                return "recover"
            return "answer"

        g = StateGraph(GraphState)
        g.add_node("plan", node_plan)
        g.add_node("execute", node_execute)
        g.add_node("recover", node_recover)
        g.add_node("answer", node_answer)

        g.set_entry_point("plan")
        g.add_edge("plan", "execute")
        g.add_conditional_edges("execute", route_after_execute,
                                 {"recover": "recover", "answer": "answer"})
        g.add_edge("recover", "execute")
        g.add_edge("answer", END)

        return g.compile()
