# Does Fine-Tuning Make Small LLMs More Robust to Faulty Tool Outputs?
### A Controlled Study with Gemma 2B and Phi-3 Mini

**CS 6180 – Foundations of Generative AI | Final Project (M3)**
Team 18: Jatan Nitesh Patel, Sam Selvaraj, Silas Bates
Supervised by Prof. Ryan Rad | Khoury College of Computer Science, Northeastern University

---

## Research Question

When you fine-tune a small language model on a tool-calling dataset, does it get better at *recovering from faulty tool outputs* — or just better at calling tools in the first place? Does model capacity matter more than fine-tuning?

We compare **Gemma 2B** and **Phi-3 Mini 3.8B**, fine-tune both with QLoRA on the same dataset, and test them inside an agent pipeline where tool outputs are deliberately corrupted in three ways.

---

## Project Structure

```
.
├── src/
│   ├── tools/
│   │   ├── simulated_tools.py      # 4 deterministic tools (weather, calc, DB, search)
│   │   └── fault_injector.py       # Wraps tools to inject null/wrong/format faults
│   ├── agent/
│   │   ├── pipeline.py             # Stateful agent loop (plan -> execute -> check -> recover -> respond)
│   │   ├── recovery.py             # Self-correction and majority voting implementations
│   │   └── prompts.py              # System prompt builder + chat template helpers (Gemma/Phi-3)
│   ├── finetune/
│   │   ├── dataset_prep.py         # glaive-function-calling-v2 loader and formatter
│   │   └── qlora_trainer.py        # QLoRA training wrapper (PEFT + bitsandbytes)
│   ├── evaluation/
│   │   ├── test_suite.py           # 200 test tasks (50 per tool category)
│   │   ├── metrics.py              # QueryResult, ExperimentMetrics, MetricsTracker, stats tests
│   │   ├── run_experiments.py      # Full experiment matrix runner (ExperimentRunner)
│   │   └── forgetting_benchmark.py # Catastrophic forgetting evaluation
│   └── analysis/
│       └── visualize.py            # Figures and tables for the report
│
├── notebooks/
│   ├── kaggle/                             # Notebooks as run on Kaggle (T4 GPU)
|      ├── notebook-1-setup-and-baseline.ipynb
│      ├── notebook-2-fine-tune-gemma-2b.ipynb   # QLoRA fine-tune Gemma 2B
│      ├── notebook-3-phi.ipynb              # QLoRA fine-tune Phi-3 Mini
│      └── notebook-4.ipynb                      # Fault injection experiments (full matrix)
│                
├── requirements.txt

```

---

## Experimental Setup

### Models

| Model | HuggingFace ID | Parameters |
|-------|---------------|------------|
| Gemma 2B | `google/gemma-2b-it` | 2B |
| Phi-3 Mini | `microsoft/Phi-3-mini-4k-instruct` | 3.8B |

Both are evaluated in base (instruction-tuned) and QLoRA fine-tuned states.

### Simulated Tools

| Tool | Description |
|------|-------------|
| `weather_lookup(city, date)` | Returns temperature, condition, humidity (static seed-42 data) |
| `calculator(expression)` | Safely evaluates arithmetic in a sandboxed environment |
| `database_query(table, filters, limit)` | Queries in-memory store (50 customers, 50 products, 100 orders) |
| `web_search(query, num_results)` | Returns mock search snippets |

### Fault Types

| Fault | Description |
|-------|-------------|
| `null_return` | Replaces output with one of 9 null-like values (None, empty dict/list, etc.) |
| `wrong_output` | Perturbs numeric fields by +/-25%, flips booleans, swaps categorical strings |
| `bad_format` | Applies one of 5 structural corruptions (truncation, missing braces, XML, key=value, double-encoding) |

### Recovery Strategies

| Strategy | How it works |
|----------|-------------|
| **Self-Correction (SC)** | Detects bad output via heuristics, injects error context, retries up to R=3 times |
| **Majority Voting (MV)** | Samples k=3 independent tool calls, aggregates via median (numeric) and mode (categorical) |

### Experiment Matrix

```
4 checkpoints (Gemma base, Gemma FT, Phi-3 base, Phi-3 FT)
  x 3 fault types (null_return, wrong_output, bad_format)
  x 2 injection rates (0.3, 0.7)
  x 2 recovery strategies (self_correction, majority_voting)
  x 20 tasks per cell
= 960 total inference calls across 48 conditions
```

> Note: 20 tasks per cell was used due to GPU memory and runtime constraints on Kaggle T4.
> The full test suite contains 200 tasks (50 per tool category).

---

## Results Summary

**30% injection rate** -- majority voting dominates for wrong_output and bad_format:

| Model | State | Fault | SC | MV |
|-------|-------|-------|----|----|
| Phi-3 Mini | Base | wrong_output | 75% | **100%** |
| Phi-3 Mini | FT | wrong_output | 75% | **95%** |
| Gemma 2B | Base | wrong_output | 35% | **70%** |
| Gemma 2B | FT | wrong_output | 40% | **85%** |

**70% injection rate** -- self-correction leads for null_return in Phi-3:

| Model | State | Fault | SC | MV |
|-------|-------|-------|----|----|
| Phi-3 Mini | FT | null_return | **70%** | 25% |
| Gemma 2B | FT | null_return | **10%** | 15% |

Key finding: Gemma-2B fine-tuning *hurts* null_return robustness at high fault rates (10% FT vs 30% base with SC at 70% injection).

---

## How to Run

### On Kaggle (recommended -- T4 GPU free tier)

1. Upload the project zip to a Kaggle dataset
2. Open a new Kaggle notebook and attach the dataset
3. Run notebooks in this order:

| Notebook | Purpose | GPU | Est. Time |
|----------|---------|-----|-----------|
| `notebook-2-fine-tune-gemma-2b (1).ipynb` | QLoRA fine-tune Gemma 2B | T4 | ~2-3 hours |
| `notebook-3-phi (1) (1).ipynb` | QLoRA fine-tune Phi-3 Mini | T4 | ~1-2 hours |
| `notebook-4 (1).ipynb` | Full fault injection experiments | T4 | ~6-8 hours |

### On Google Colab

Same approach -- attach Google Drive, run notebooks in order. A100 recommended for fine-tuning.

### Install dependencies

```bash
pip install -r requirements.txt
```

### W&B Experiment Tracking

All runs log to Weights and Biases. Set your key before running:
```python
import os
os.environ["WANDB_API_KEY"] = "your-key-here"
```
Or run `wandb login` in terminal.

---

## Fine-Tuning Details (QLoRA)

| Setting | Gemma 2B | Phi-3 Mini |
|---------|----------|------------|
| Dataset | glaive-function-calling-v2 | glaive-function-calling-v2 |
| Train examples | 7,000 | 7,000 |
| LoRA rank (r) | 16 | 16 |
| LoRA alpha | 32 | 32 |
| LoRA dropout | 0.05 | 0.05 |
| Target modules | q/k/v/o_proj, gate/up/down_proj (7) | qkv_proj, o_proj, gate_up_proj, down_proj (4) |
| Quantization | 4-bit NF4 | 4-bit NF4 |
| Compute dtype | bfloat16 | bfloat16 |
| Epochs | 3 | 2 |
| Effective batch size | 16 (4 x 4 grad accum) | 16 (4 x 4 grad accum) |
| Learning rate | 2e-4 (cosine + 3% warmup) | 2e-4 (cosine + 3% warmup) |
| Optimizer | paged_adamw_32bit | paged_adamw_32bit |
| Train loss | 1.25 -> 0.12 (500 steps) | 1.05 -> 0.10 (75 steps) |

---

## Metrics Tracked

- **Answer accuracy** -- fraction of tasks with correct final answer
- **Tool selection accuracy** -- fraction with correct tool chosen
- **Recovery rate** -- fraction of faulted tasks successfully recovered
- **Fault detection rate** -- fraction of faulty results correctly flagged
- **False alarm rate** -- fraction of clean results incorrectly flagged as faulty
- **Failure mode distribution** -- SUCCESS / SILENT_WRONG / EXPLICIT_ERROR / HALLUCINATED_FIX / CORRECT_REFUSAL

---

## References

- glaive-function-calling-v2: https://huggingface.co/datasets/glaiveai/glaive-function-calling-v2
- Gemma 2B: google/gemma-2b-it
- Phi-3 Mini: microsoft/Phi-3-mini-4k-instruct
- QLoRA: Dettmers et al. (2023) https://arxiv.org/abs/2305.14314
- LoRA: Hu et al. (2022) https://arxiv.org/abs/2106.09685